-- ============================================================================
-- 0001_schema.sql
-- Schema completo do Van Helsing RPG.
--
-- Substitui qualquer rascunho anterior (profiles/campaigns/campaign_members)
-- que ainda não tenha sido aplicado em um projeto Supabase real. Se você já
-- rodou uma versão anterior deste schema, descomente e rode primeiro:
--
--   drop table if exists public.campaign_members cascade;
--   drop table if exists public.campaigns cascade;
--   drop table if exists public.profiles cascade;
--
-- Modelo:
--   Campaigns  = definição da aventura/cenário (pode ser reutilizada por
--                várias Rooms, como um "módulo" de aventura).
--   Rooms      = a mesa de jogo em si ("sala"): sessão com código de
--                convite, membros, estado de cena atual.
--   RoomMembers = tabela de junção Users <-> Rooms (não pedida
--                explicitamente, mas necessária para representar a relação
--                N:N de "quem está em qual sala").
-- ============================================================================

create extension if not exists "pgcrypto";

-- ============================================================================
-- FUNÇÕES AUXILIARES (definidas antes das tabelas que as usam em triggers)
-- ============================================================================

-- Atualiza automaticamente a coluna updated_at em UPDATEs.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ============================================================================
-- 1) USERS
-- Estende auth.users (1:1). Criado automaticamente via trigger
-- on_auth_user_created, cobrindo e-mail/senha, login anônimo e Google.
-- ============================================================================
create table public.users (
  id uuid primary key references auth.users (id) on delete cascade,
  username text,
  avatar_url text,
  bio text,
  created_at timestamptz not null default now()
);

comment on table public.users is 'Perfil público de cada usuário autenticado (1:1 com auth.users).';

-- ============================================================================
-- 2) CAMPAIGNS
-- Definição da aventura/cenário. Pode ser reaproveitada por múltiplas Rooms.
-- ============================================================================
create table public.campaigns (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  setting_theme text,
  created_by uuid not null references public.users (id) on delete cascade,
  created_at timestamptz not null default now()
);

comment on table public.campaigns is 'Definição da aventura/cenário (tema, descrição) — o "módulo" jogado em uma ou mais Rooms.';

-- ============================================================================
-- 3) ROOMS ("salas")
-- A mesa de jogo em si: sessão com código de convite, dono e estado de cena.
-- ============================================================================
create table public.rooms (
  id uuid primary key default gen_random_uuid(),
  campaign_id uuid references public.campaigns (id) on delete set null,
  name text not null,
  invite_code text not null unique,
  owner_id uuid not null references public.users (id) on delete cascade,
  status text not null default 'active'
    check (status in ('draft', 'active', 'paused', 'ended')),
  gm_mode text not null default 'ai'
    check (gm_mode in ('ai', 'hybrid')),
  current_scene jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

comment on table public.rooms is 'Sala/mesa de jogo: sessão real onde jogadores entram via invite_code.';

-- ============================================================================
-- 4) ROOM_MEMBERS
-- Junção Users <-> Rooms. Necessária para representar "quem está em qual
-- sala" (relação N:N), embora não tenha sido listada explicitamente.
-- ============================================================================
create table public.room_members (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms (id) on delete cascade,
  user_id uuid not null references public.users (id) on delete cascade,
  role text not null default 'player'
    check (role in ('player', 'spectator', 'co-gm')),
  joined_at timestamptz not null default now(),
  unique (room_id, user_id)
);

comment on table public.room_members is 'Relação N:N entre usuários e salas, com o papel de cada membro.';

-- ============================================================================
-- 5) CHARACTERS
-- Ficha de personagem de um jogador dentro de uma Room específica.
-- ============================================================================
create table public.characters (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms (id) on delete cascade,
  user_id uuid not null references public.users (id) on delete cascade,
  name text not null,
  class text,
  level int not null default 1 check (level >= 1),
  attributes jsonb not null default '{}'::jsonb,
  hp_current int not null default 10,
  hp_max int not null default 10,
  sanity_current int not null default 10,
  sanity_max int not null default 10,
  status_effects jsonb not null default '[]'::jsonb,
  avatar_url text,
  created_at timestamptz not null default now(),
  check (hp_current <= hp_max),
  check (sanity_current <= sanity_max)
);

comment on table public.characters is 'Ficha de personagem de um jogador em uma sala específica.';

-- ============================================================================
-- 6) ITEMS
-- Catálogo global de itens (armas, relíquias, poções...).
-- ============================================================================
create table public.items (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  type text not null
    check (type in ('weapon', 'armor', 'relic', 'potion', 'tool', 'misc')),
  rarity text not null default 'common'
    check (rarity in ('common', 'uncommon', 'rare', 'epic', 'legendary')),
  description text,
  effects jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

comment on table public.items is 'Catálogo global de itens disponíveis no jogo.';

-- ============================================================================
-- 7) INVENTORY
-- Junção Characters <-> Items, com quantidade e status de equipado.
-- ============================================================================
create table public.inventory (
  id uuid primary key default gen_random_uuid(),
  character_id uuid not null references public.characters (id) on delete cascade,
  item_id uuid not null references public.items (id) on delete cascade,
  quantity int not null default 1 check (quantity >= 0),
  equipped boolean not null default false,
  acquired_at timestamptz not null default now(),
  unique (character_id, item_id)
);

comment on table public.inventory is 'Itens que cada personagem possui, com quantidade e status de equipado.';

-- ============================================================================
-- 8) MONSTER_CODEX
-- Bestiário global (catálogo de monstros/criaturas reutilizável).
-- ============================================================================
create table public.monster_codex (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  lore text,
  stats jsonb not null default '{}'::jsonb,
  behavior_profile jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

comment on table public.monster_codex is 'Bestiário global: catálogo de monstros/criaturas reutilizável entre salas.';

-- ============================================================================
-- 9) NPCS
-- Instância de um NPC/monstro dentro de uma Room, opcionalmente baseada em
-- um template do MonsterCodex.
-- ============================================================================
create table public.npcs (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms (id) on delete cascade,
  monster_codex_id uuid references public.monster_codex (id) on delete set null,
  name text not null,
  role text not null default 'neutral'
    check (role in ('ally', 'neutral', 'villain', 'monster')),
  description text,
  stats jsonb not null default '{}'::jsonb,
  hp_current int,
  hp_max int,
  avatar_url text,
  created_at timestamptz not null default now(),
  check (hp_current is null or hp_max is null or hp_current <= hp_max)
);

comment on table public.npcs is 'NPCs/monstros ativos em uma sala, opcionalmente baseados no MonsterCodex.';

-- ============================================================================
-- 10) QUESTS
-- Missões/objetivos de uma Room.
-- ============================================================================
create table public.quests (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms (id) on delete cascade,
  title text not null,
  description text,
  status text not null default 'active'
    check (status in ('active', 'completed', 'failed')),
  objectives jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

comment on table public.quests is 'Missões/objetivos narrativos de uma sala.';

-- ============================================================================
-- 11) MESSAGES
-- Log de chat e narração da IA Mestre dentro de uma Room.
-- ============================================================================
create table public.messages (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms (id) on delete cascade,
  sender_type text not null
    check (sender_type in ('player', 'gm_ai', 'system')),
  sender_id uuid references public.users (id) on delete set null,
  message_type text not null default 'chat'
    check (message_type in ('chat', 'narration', 'system')),
  content text not null,
  created_at timestamptz not null default now(),
  check (
    (sender_type = 'player' and sender_id is not null)
    or (sender_type in ('gm_ai', 'system'))
  )
);

comment on table public.messages is 'Log de chat, narração da IA Mestre e mensagens de sistema de uma sala.';

-- ============================================================================
-- 12) WORLD_STATE
-- Snapshot persistente do estado do mundo/campanha em uma Room (1:1).
-- ============================================================================
create table public.world_state (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null unique references public.rooms (id) on delete cascade,
  state jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

comment on table public.world_state is 'Estado persistente do mundo (flags, locais descobertos, reputação) por sala — 1:1 com Rooms.';

-- ============================================================================
-- 13) DICE_ROLLS
-- Histórico de rolagens de dados de uma Room.
-- ============================================================================
create table public.dice_rolls (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms (id) on delete cascade,
  character_id uuid references public.characters (id) on delete set null,
  user_id uuid references public.users (id) on delete set null,
  expression text not null,
  rolls jsonb not null default '[]'::jsonb,
  total int not null,
  reason text,
  created_at timestamptz not null default now()
);

comment on table public.dice_rolls is 'Histórico de rolagens de dados realizadas em uma sala.';

-- ============================================================================
-- ÍNDICES
-- ============================================================================
create index idx_campaigns_created_by on public.campaigns (created_by);

create index idx_rooms_campaign on public.rooms (campaign_id);
create index idx_rooms_owner on public.rooms (owner_id);
create index idx_rooms_invite_code on public.rooms (invite_code);

create index idx_room_members_room on public.room_members (room_id);
create index idx_room_members_user on public.room_members (user_id);

create index idx_characters_room on public.characters (room_id);
create index idx_characters_user on public.characters (user_id);

create index idx_inventory_character on public.inventory (character_id);
create index idx_inventory_item on public.inventory (item_id);

create index idx_npcs_room on public.npcs (room_id);
create index idx_npcs_monster_codex on public.npcs (monster_codex_id);

create index idx_quests_room on public.quests (room_id);

create index idx_messages_room on public.messages (room_id);
create index idx_messages_sender on public.messages (sender_id);
create index idx_messages_room_created_at on public.messages (room_id, created_at);

create index idx_dice_rolls_room on public.dice_rolls (room_id);
create index idx_dice_rolls_character on public.dice_rolls (character_id);

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Cria automaticamente um registro em public.users quando um novo usuário se
-- autentica pela primeira vez — cobre e-mail/senha, login anônimo e Google,
-- já que os três fluxos inserem uma linha em auth.users.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.users (id, username)
  values (
    new.id,
    coalesce(
      new.raw_user_meta_data ->> 'username',
      new.raw_user_meta_data ->> 'full_name',
      'Caçador Anônimo'
    )
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

create trigger set_rooms_updated_at
  before update on public.rooms
  for each row execute procedure public.set_updated_at();

create trigger set_quests_updated_at
  before update on public.quests
  for each row execute procedure public.set_updated_at();

create trigger set_world_state_updated_at
  before update on public.world_state
  for each row execute procedure public.set_updated_at();

-- ============================================================================
-- ROW LEVEL SECURITY
--
-- Estratégia: todas as tabelas têm RLS habilitado com policies de SELECT
-- apenas (baseadas em membership de sala). Toda escrita (INSERT/UPDATE/
-- DELETE) é feita exclusivamente pelo backend usando a service role key,
-- que ignora RLS — isso permite validar regras de negócio (geração de
-- invite_code, checagem de duplicidade, cálculo de dano etc.) antes de
-- gravar qualquer coisa no banco.
-- ============================================================================

alter table public.users enable row level security;
alter table public.campaigns enable row level security;
alter table public.rooms enable row level security;
alter table public.room_members enable row level security;
alter table public.characters enable row level security;
alter table public.items enable row level security;
alter table public.inventory enable row level security;
alter table public.monster_codex enable row level security;
alter table public.npcs enable row level security;
alter table public.quests enable row level security;
alter table public.messages enable row level security;
alter table public.world_state enable row level security;
alter table public.dice_rolls enable row level security;

-- Função auxiliar: o usuário atual é membro da sala informada?
create or replace function public.is_room_member(target_room_id uuid)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from public.room_members
    where room_id = target_room_id
      and user_id = auth.uid()
  );
$$;

-- users: qualquer autenticado pode ver perfis; só pode editar o próprio.
create policy "users_select_authenticated"
  on public.users for select
  to authenticated
  using (true);

create policy "users_update_own"
  on public.users for update
  to authenticated
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- campaigns: visível para quem criou ou para membros de alguma sala que a usa.
create policy "campaigns_select_owner_or_room_member"
  on public.campaigns for select
  to authenticated
  using (
    created_by = auth.uid()
    or exists (
      select 1 from public.rooms r
      where r.campaign_id = campaigns.id
        and public.is_room_member(r.id)
    )
  );

-- rooms: visível para membros da sala.
create policy "rooms_select_members"
  on public.rooms for select
  to authenticated
  using (public.is_room_member(id));

-- room_members: visível para outros membros da mesma sala.
create policy "room_members_select_same_room"
  on public.room_members for select
  to authenticated
  using (public.is_room_member(room_id));

-- characters: visível para membros da mesma sala do personagem.
create policy "characters_select_room_members"
  on public.characters for select
  to authenticated
  using (public.is_room_member(room_id));

-- items, monster_codex: catálogos globais, leitura livre para autenticados.
create policy "items_select_authenticated"
  on public.items for select
  to authenticated
  using (true);

create policy "monster_codex_select_authenticated"
  on public.monster_codex for select
  to authenticated
  using (true);

-- inventory: visível para membros da sala do personagem dono do item.
create policy "inventory_select_room_members"
  on public.inventory for select
  to authenticated
  using (
    exists (
      select 1 from public.characters c
      where c.id = inventory.character_id
        and public.is_room_member(c.room_id)
    )
  );

-- npcs, quests, messages, world_state, dice_rolls: visíveis para membros da sala.
create policy "npcs_select_room_members"
  on public.npcs for select
  to authenticated
  using (public.is_room_member(room_id));

create policy "quests_select_room_members"
  on public.quests for select
  to authenticated
  using (public.is_room_member(room_id));

create policy "messages_select_room_members"
  on public.messages for select
  to authenticated
  using (public.is_room_member(room_id));

create policy "world_state_select_room_members"
  on public.world_state for select
  to authenticated
  using (public.is_room_member(room_id));

create policy "dice_rolls_select_room_members"
  on public.dice_rolls for select
  to authenticated
  using (public.is_room_member(room_id));
