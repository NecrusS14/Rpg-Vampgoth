# Arquitetura — RPG de Mesa Online "Van Helsing" com IA Mestre

## 1. Visão Geral

Um RPG de mesa multiplayer em tempo real, ambientado num universo gótico/vitoriano inspirado em Van Helsing (caçadores de monstros, ocultismo, Europa do Leste sombria). Uma IA atua como **Mestre da Campanha (Game Master AI)**, narrando a história, controlando NPCs/monstros, arbitrando regras e reagindo às ações dos jogadores em tempo real.

### Stack

| Camada | Tecnologia |
|---|---|
| Frontend | React + Vite + TypeScript + TailwindCSS |
| Tempo real | Socket.IO (client/server) |
| Backend | Node.js + Express + TypeScript |
| Banco de dados / Auth | Supabase (Postgres + Auth + Realtime opcional + Storage) |
| IA Mestre | LLM via API (Anthropic Claude) orquestrado no backend |
| Deploy Frontend | Vercel |
| Deploy Backend | Railway |

### Princípio arquitetural central

- **REST (Express + Supabase)** cuida de tudo que é persistente e transacional: autenticação, criação de campanha, fichas de personagem, inventário, histórico de sessões.
- **Socket.IO** cuida de tudo que é síncrono/tempo real: narração da IA, rolagens de dados, turnos de combate, chat de mesa, presença de jogadores.
- **A IA Mestre roda no backend**, nunca no cliente (evita expor prompts/chaves e permite validar regras antes de aplicar efeitos no jogo).

---

## 2. Arquitetura Geral (visão macro)

```
┌─────────────────────────┐         ┌──────────────────────────────┐
│        VERCEL           │         │           RAILWAY             │
│  Frontend React/Vite    │ HTTPS   │  Backend Node/Express         │
│  - UI do jogo           │◄───────►│  - REST API                   │
│  - Cliente Socket.IO    │  WSS    │  - Socket.IO Server            │
│  - Estado local (Zustand│◄───────►│  - Orquestrador da IA Mestre    │
│    /Redux)              │         │  - Motor de regras (dados,      │
└─────────────────────────┘         │    combate, XP)               │
                                     │  - Cliente Supabase (service)   │
                                     │  - Cliente Anthropic API        │
                                     └──────────────┬────────────────┘
                                                     │
                                                     ▼
                                     ┌──────────────────────────────┐
                                     │          SUPABASE             │
                                     │  - Postgres (dados do jogo)   │
                                     │  - Auth (login jogadores)     │
                                     │  - Storage (avatares, mapas)  │
                                     │  - Row Level Security (RLS)   │
                                     └──────────────────────────────┘
```

### Por que não Supabase Realtime em vez de Socket.IO?

Supabase Realtime é ótimo para sincronizar *estado de tabelas*, mas a IA Mestre precisa de lógica de orquestração custom (turnos, validação de ações, chamadas ao LLM, streaming de narração). Socket.IO nos dá controle fino sobre rooms (uma por campanha/sessão), broadcast seletivo e eventos customizados de jogo — Supabase continua responsável apenas pela camada de persistência.

---

## 3. Estrutura de Pastas

### 3.1 Monorepo (recomendado)

```
van-helsing-rpg/
├── apps/
│   ├── web/                        # Frontend (Vercel)
│   │   ├── src/
│   │   │   ├── components/
│   │   │   ├── features/
│   │   │   ├── hooks/
│   │   │   ├── lib/
│   │   │   ├── pages/ (ou routes/)
│   │   │   ├── store/
│   │   │   ├── styles/
│   │   │   ├── types/
│   │   │   ├── App.tsx
│   │   │   └── main.tsx
│   │   ├── index.html
│   │   ├── vite.config.ts
│   │   ├── tailwind.config.ts
│   │   ├── tsconfig.json
│   │   └── vercel.json
│   │
│   └── server/                     # Backend (Railway)
│       ├── src/
│       │   ├── config/             # env, supabase client, socket config
│       │   ├── modules/
│       │   │   ├── auth/
│       │   │   ├── campaigns/
│       │   │   ├── characters/
│       │   │   ├── sessions/
│       │   │   ├── combat/
│       │   │   └── gamemaster/     # orquestração da IA
│       │   ├── sockets/
│       │   │   ├── handlers/       # um arquivo por domínio de evento
│       │   │   ├── middlewares/    # auth do socket, rate limit
│       │   │   └── index.ts
│       │   ├── routes/             # REST endpoints
│       │   ├── services/
│       │   │   ├── ai/             # cliente LLM, prompt builder
│       │   │   ├── dice/           # motor de rolagem de dados
│       │   │   └── rules-engine/   # regras de combate/progressão
│       │   ├── db/                 # queries supabase, migrations
│       │   ├── types/
│       │   ├── utils/
│       │   ├── app.ts
│       │   └── server.ts
│       ├── tsconfig.json
│       ├── railway.json (ou nixpacks.toml)
│       └── package.json
│
├── packages/
│   └── shared/                     # Tipos e contratos compartilhados
│       ├── src/
│       │   ├── types/              # DTOs, Character, Campaign, etc.
│       │   ├── socket-events.ts    # nomes e payloads dos eventos
│       │   └── constants/          # regras de jogo, tabelas de dano
│       └── package.json
│
├── supabase/
│   ├── migrations/
│   └── seed.sql
│
├── package.json                    # workspaces root
├── turbo.json (ou pnpm-workspace.yaml)
└── README.md
```

**Por que monorepo com pacote `shared`:** garante que os tipos de eventos Socket.IO e DTOs sejam idênticos no client e no server (contrato único, sem duplicação, sem dessincronização de payloads).

---

## 4. Fluxo de Comunicação

### 4.1 Camadas de comunicação

1. **REST (HTTPS)** — operações CRUD e autenticação:
   - Login/registro (delegado ao Supabase Auth)
   - Criar/editar campanha
   - Criar/editar ficha de personagem
   - Listar campanhas do usuário
   - Histórico de sessões passadas (log de narração)

2. **WebSocket (Socket.IO)** — tudo que acontece "na mesa":
   - Entrar/sair da sala da campanha (`room = campaign_id` ou `session_id`)
   - Ações dos jogadores (falar, atacar, usar item, rolar dado)
   - Respostas narrativas da IA Mestre (com streaming de texto)
   - Sincronização de estado de combate (turnos, iniciativa, HP)
   - Presença (quem está online, digitando, etc.)

### 4.2 Fluxo típico de uma jogada

```
Jogador (front)
   │ emit "player:action" {type:"attack", targetId, weaponId}
   ▼
Socket.IO Server (Railway)
   │ 1. Valida sessão/auth do socket
   │ 2. Rules Engine calcula resultado bruto (rolagem de dado, dano)
   │ 3. Persiste evento no Supabase (game_events)
   │ 4. Monta contexto (histórico recente + estado atual) 
   │ 5. Chama IA Mestre (Anthropic API) para narrar o resultado
   ▼
IA Mestre (LLM)
   │ Gera narração em streaming
   ▼
Socket.IO Server
   │ emit "gm:narration:chunk" (stream) → todos na room
   │ emit "combat:state:update" (HP, turno) → todos na room
   │ persiste narração final em game_events
   ▼
Todos os jogadores da room (front)
   recebem narração em tempo real + atualização de estado
```

### 4.3 Autenticação no Socket.IO

- Cliente obtém JWT do Supabase Auth via REST.
- Ao conectar no Socket.IO, envia o JWT no `auth` do handshake.
- Middleware do servidor valida o JWT com Supabase (`supabase.auth.getUser(token)`), anexa `userId` ao socket.
- Sem token válido → conexão recusada.

---

## 5. Banco de Dados (Supabase / Postgres)

### 5.1 Modelagem das Tabelas

**`profiles`** (estende `auth.users`)
| Coluna | Tipo | Descrição |
|---|---|---|
| id | uuid (PK, = auth.users.id) | |
| username | text | |
| avatar_url | text | |
| created_at | timestamptz | |

**`campaigns`**
| Coluna | Tipo | Descrição |
|---|---|---|
| id | uuid (PK) | |
| name | text | Nome da campanha |
| description | text | |
| setting_theme | text | ex: "Transilvânia 1893" |
| owner_id | uuid (FK profiles) | Mestre humano dono/criador da sala |
| gm_mode | text | `'ai'` \| `'hybrid'` |
| status | text | `'draft'`, `'active'`, `'paused'`, `'ended'` |
| current_scene | jsonb | snapshot do estado narrativo atual |
| created_at | timestamptz | |

**`campaign_members`**
| Coluna | Tipo | Descrição |
|---|---|---|
| id | uuid (PK) | |
| campaign_id | uuid (FK) | |
| user_id | uuid (FK) | |
| role | text | `'player'` \| `'spectator'` \| `'co-gm'` |
| joined_at | timestamptz | |

**`characters`**
| Coluna | Tipo | Descrição |
|---|---|---|
| id | uuid (PK) | |
| campaign_id | uuid (FK) | |
| user_id | uuid (FK) | |
| name | text | |
| class | text | ex: Caçador, Ocultista, Padre-Guerreiro |
| level | int | |
| attributes | jsonb | força, destreza, intelecto, vontade... |
| hp_current | int | |
| hp_max | int | |
| sanity_current | int | mecânica de sanidade (tema gótico) |
| inventory | jsonb / tabela separada | |
| status_effects | jsonb | maldições, sangramento, etc. |
| avatar_url | text | |
| created_at | timestamptz | |

**`items`** (catálogo global)
| Coluna | Tipo | Descrição |
|---|---|---|
| id | uuid (PK) | |
| name | text | |
| type | text | arma, relíquia, poção, artefato |
| rarity | text | |
| effects | jsonb | |

**`character_inventory`**
| Coluna | Tipo | Descrição |
|---|---|---|
| id | uuid (PK) | |
| character_id | uuid (FK) | |
| item_id | uuid (FK) | |
| quantity | int | |
| equipped | boolean | |

**`sessions`** (uma "sessão de jogo" dentro de uma campanha)
| Coluna | Tipo | Descrição |
|---|---|---|
| id | uuid (PK) | |
| campaign_id | uuid (FK) | |
| started_at | timestamptz | |
| ended_at | timestamptz | |
| summary | text | resumo gerado pela IA ao fim da sessão |

**`game_events`** (log imutável — fonte da verdade narrativa)
| Coluna | Tipo | Descrição |
|---|---|---|
| id | uuid (PK) | |
| session_id | uuid (FK) | |
| actor_type | text | `'player'` \| `'gm_ai'` \| `'system'` |
| actor_id | uuid nullable | |
| event_type | text | `'narration'`, `'action'`, `'dice_roll'`, `'combat_update'` |
| payload | jsonb | conteúdo estruturado do evento |
| created_at | timestamptz | |

> `game_events` funciona como **event sourcing**: o estado atual da campanha pode ser reconstruído a partir dele, e é também a base do contexto enviado ao LLM (últimos N eventos relevantes).

**`combat_encounters`**
| Coluna | Tipo | Descrição |
|---|---|---|
| id | uuid (PK) | |
| session_id | uuid (FK) | |
| status | text | `'active'` \| `'resolved'` |
| turn_order | jsonb | array ordenado de participant_ids |
| current_turn_index | int | |

**`combat_participants`**
| Coluna | Tipo | Descrição |
|---|---|---|
| id | uuid (PK) | |
| encounter_id | uuid (FK) | |
| participant_type | text | `'character'` \| `'monster'` |
| participant_ref_id | uuid | |
| initiative | int | |
| hp_current | int | |

**`monsters`** (catálogo/bestiário)
| Coluna | Tipo | Descrição |
|---|---|---|
| id | uuid (PK) | |
| name | text | |
| lore | text | trecho de fluff para a IA usar na narração |
| stats | jsonb | |
| behavior_profile | jsonb | dicas de comportamento para a IA (agressivo, furtivo...) |

### 5.2 Row Level Security (RLS)

- `characters`: usuário só edita a própria ficha; leitura liberada para membros da mesma `campaign`.
- `campaigns`: leitura/escrita restrita a `owner_id` e membros em `campaign_members`.
- `game_events`: inserção apenas via backend (service role), leitura para membros da campanha.

---

## 6. Eventos Socket.IO

Namespacing sugerido por domínio (`prefixo:ação`), organizados em rooms por `session_id`.

### 6.1 Conexão / Presença

| Evento | Direção | Payload |
|---|---|---|
| `session:join` | client → server | `{ sessionId }` |
| `session:leave` | client → server | `{ sessionId }` |
| `presence:update` | server → clients | `{ userId, status: 'online'|'typing'|'idle' }` |
| `session:state:sync` | server → client (ao entrar) | snapshot completo do estado atual |

### 6.2 Narração / IA Mestre

| Evento | Direção | Payload |
|---|---|---|
| `gm:narration:start` | server → clients | `{ eventId }` |
| `gm:narration:chunk` | server → clients | `{ eventId, textChunk }` (streaming) |
| `gm:narration:end` | server → clients | `{ eventId, fullText }` |
| `gm:scene:update` | server → clients | `{ sceneDescription, imageUrl? }` |

### 6.3 Ações dos Jogadores

| Evento | Direção | Payload |
|---|---|---|
| `player:chat` | client → server → clients | `{ message }` (fala em personagem / OOC) |
| `player:action` | client → server | `{ type, targetId?, itemId?, details }` |
| `player:dice:roll` | client → server | `{ diceExpression, reason }` |
| `dice:result` | server → clients | `{ userId, expression, rolls, total }` |

### 6.4 Combate

| Evento | Direção | Payload |
|---|---|---|
| `combat:start` | server → clients | `{ encounterId, turnOrder }` |
| `combat:turn:change` | server → clients | `{ currentParticipantId }` |
| `combat:action:submit` | client → server | `{ actionType, targetId, itemId }` |
| `combat:state:update` | server → clients | `{ participants: [...hp, status] }` |
| `combat:end` | server → clients | `{ result: 'victory'|'defeat'|'flee', rewards }` |

### 6.5 Sistema / Erros

| Evento | Direção | Payload |
|---|---|---|
| `error` | server → client | `{ code, message }` |
| `rate_limit:warning` | server → client | `{ retryAfterMs }` |

---

## 7. Fluxo da IA Mestre (Game Master AI)

### 7.1 Componentes do orquestrador (`services/ai` + `modules/gamemaster`)

1. **Context Builder**
   - Busca últimos N eventos relevantes de `game_events` da sessão.
   - Busca estado atual: personagens presentes, HP, inventário relevante, cena atual (`campaigns.current_scene`).
   - Monta um prompt estruturado (system prompt fixo de "Mestre de Van Helsing" + contexto dinâmico + última ação do jogador).

2. **Rules Engine (determinístico, roda ANTES da IA)**
   - Rolagens de dados, cálculo de dano, verificação de sucesso/falha por atributos.
   - A IA **não decide números** — ela narra resultados que o motor de regras já calculou. Isso evita alucinação de regras e garante jogo justo.

3. **Chamada ao LLM (Anthropic API)**
   - Envia: system prompt (persona do Mestre, tom gótico, regras de narrativa) + contexto + resultado mecânico já calculado.
   - Recebe resposta em streaming.
   - Modelo sugerido: usar o mais capaz disponível para narrativa longa e consistência de lore (a decidir conforme custo/latência desejados).

4. **Streaming para os clientes**
   - Cada chunk do LLM é repassado via `gm:narration:chunk` assim que chega.

5. **Persistência**
   - Ao final, salva o texto completo em `game_events` (`actor_type = 'gm_ai'`).
   - Atualiza `campaigns.current_scene` se a cena mudou.

6. **Ações estruturadas da IA (function calling / tool use)**
   - A IA pode "chamar ferramentas" internas para efeitos de jogo, por exemplo:
     - `spawn_monster(monster_id, count)`
     - `apply_status_effect(character_id, effect)`
     - `trigger_combat(participants)`
     - `award_item(character_id, item_id)`
   - Essas "tools" são validadas e executadas pelo backend (nunca aplicadas cegamente) — a IA sugere, o motor de regras aplica.

### 7.2 Diagrama do fluxo da IA

```
Ação do jogador
     │
     ▼
Rules Engine (dados, dano, sucesso/falha) ── determinístico
     │
     ▼
Context Builder (histórico + estado atual)
     │
     ▼
LLM (Anthropic API) — narra o resultado, pode sugerir tool_use
     │
     ├── texto narrativo (stream) ──► clientes via Socket.IO
     │
     └── tool_use sugerido ──► validação no backend ──► aplica efeito no DB
                                                    └──► emite combat:state:update etc.
```

### 7.3 Gestão de contexto/custo

- Resumir sessões antigas (`sessions.summary`) para não estourar a janela de contexto.
- Enviar apenas eventos recentes + resumo de longo prazo + ficha resumida dos personagens ativos.
- Cache de "lore fixo" da campanha (não muda a cada chamada) separado do estado dinâmico.

---

## 8. Organização dos Componentes React (Frontend)

### 8.1 Estrutura por feature (feature-based, não por tipo)

```
src/
├── components/            # componentes puramente visuais/reutilizáveis
│   ├── ui/                 # Button, Modal, Card, Tooltip (design system)
│   ├── layout/              # AppShell, Sidebar, TopBar
│   └── feedback/            # Toasts, LoadingSpinner, ErrorBoundary
│
├── features/
│   ├── auth/
│   │   ├── LoginForm.tsx
│   │   └── useAuth.ts
│   │
│   ├── campaigns/
│   │   ├── CampaignList.tsx
│   │   ├── CampaignCard.tsx
│   │   ├── CreateCampaignModal.tsx
│   │   └── useCampaigns.ts
│   │
│   ├── characters/
│   │   ├── CharacterSheet.tsx
│   │   ├── CharacterCreationWizard.tsx
│   │   ├── InventoryPanel.tsx
│   │   └── useCharacter.ts
│   │
│   ├── table/                    # a "mesa de jogo" em si
│   │   ├── GameTable.tsx          # container principal da sessão
│   │   ├── NarrationFeed.tsx       # stream de texto da IA Mestre
│   │   ├── ChatBox.tsx
│   │   ├── PlayerList.tsx
│   │   ├── DiceRoller.tsx
│   │   ├── SceneBanner.tsx         # imagem/descrição da cena atual
│   │   └── useGameSocket.ts        # hook central de conexão socket
│   │
│   └── combat/
│       ├── CombatTracker.tsx
│       ├── InitiativeOrder.tsx
│       ├── ActionMenu.tsx           # atacar, usar item, fugir...
│       └── useCombat.ts
│
├── hooks/                    # hooks genéricos (não amarrados a feature)
│   ├── useSocket.ts            # instância única do socket.io-client
│   └── useSupabaseAuth.ts
│
├── store/                    # estado global (Zustand recomendado)
│   ├── sessionStore.ts          # estado da sessão de jogo atual
│   ├── userStore.ts
│   └── uiStore.ts
│
├── lib/
│   ├── supabaseClient.ts
│   ├── socketClient.ts
│   └── api.ts                   # wrapper fetch para REST do backend
│
├── types/                   # importados de packages/shared quando possível
├── pages/ (ou routes/)
│   ├── LoginPage.tsx
│   ├── DashboardPage.tsx        # lista de campanhas
│   ├── CampaignSetupPage.tsx
│   └── GameTablePage.tsx        # monta GameTable + CombatTracker etc.
└── App.tsx
```

### 8.2 Gestão de estado

- **Zustand** (leve, ideal para estado de sessão em tempo real) em vez de Redux — menos boilerplate para lidar com updates frequentes vindos do socket.
- **React Query (TanStack Query)** para dados REST (campanhas, fichas) — cache, revalidação, estados de loading/error prontos.
- Socket.IO alimenta diretamente o `sessionStore` (Zustand) via listeners centralizados em `useGameSocket`.

### 8.3 Fluxo de dados no frontend

```
useGameSocket (conecta 1x por sessão)
   │
   ├─ on('gm:narration:chunk') → sessionStore.appendNarration()
   ├─ on('combat:state:update') → sessionStore.updateCombat()
   ├─ on('dice:result') → sessionStore.pushDiceLog()
   │
   ▼
Componentes consomem via seletores Zustand
   (NarrationFeed, CombatTracker, DiceRoller re-renderizam
    apenas quando sua fatia de estado muda)
```

---

## 9. Deploy

### 9.1 Frontend — Vercel

- Build: `vite build` (raiz `apps/web`).
- Variáveis de ambiente: `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_BACKEND_URL` (Railway), `VITE_SOCKET_URL`.
- `vercel.json` com rewrites de SPA (fallback para `index.html`).

### 9.2 Backend — Railway

- Root: `apps/server`, build via Nixpacks (`npm run build` → `dist/`) ou Dockerfile próprio.
- Variáveis de ambiente: `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `ANTHROPIC_API_KEY`, `CORS_ORIGIN` (URL da Vercel), `PORT`.
- Socket.IO configurado com CORS apontando exclusivamente para o domínio Vercel.
- Health check endpoint (`/health`) para o Railway monitorar.

### 9.3 Supabase

- Projeto único, migrations versionadas em `supabase/migrations` (via Supabase CLI).
- Service Role Key **somente no backend** (nunca exposta ao frontend).
- Frontend usa apenas a **anon key** + RLS para leituras diretas permitidas (ex: listar campanhas públicas), mas escritas de jogo sempre passam pelo backend para validação de regras.

---

## 10. Próximos Passos Sugeridos (após aprovação deste plano)

1. Definir o **schema JSON** exato de `attributes`, `status_effects` e `stats` (regras do sistema de jogo em si — atributos, dados de classe, fórmulas de dano).
2. Escrever o **system prompt** da IA Mestre (tom, limites de conteúdo, formato de tool calls).
3. Criar as migrations SQL do Supabase.
4. Implementar o esqueleto do monorepo (workspaces + shared types).
5. Implementar autenticação ponta a ponta (Supabase Auth + middleware Socket.IO).
6. Implementar o primeiro loop vertical: criar campanha → entrar na mesa → enviar uma ação → IA narra a resposta.

---

*Este documento cobre arquitetura, dados e fluxos. Nenhum código foi implementado nesta etapa, conforme solicitado.*
