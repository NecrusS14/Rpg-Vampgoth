// HomePage.tsx
// "Home": visão geral do jogador — boas-vindas, atalhos e campanhas recentes.

import { Link } from 'react-router-dom'
import { Swords, ScrollText, Backpack, ArrowRight } from 'lucide-react'
import AppShell from '@/components/layout/AppShell'
import Card from '@/components/ui/Card'
import Badge from '@/components/ui/Badge'
import Button from '@/components/ui/Button'
import { mockCampaigns, mockPlayer, mockQuests } from '@/lib/mockData'

const statusTone = {
  active: 'success',
  waiting: 'gold',
  paused: 'default',
} as const

const statusLabel = {
  active: 'Em andamento',
  waiting: 'Aguardando',
  paused: 'Pausada',
} as const

export default function HomePage() {
  const activeQuests = mockQuests.filter((q) => q.status === 'active')

  return (
    <AppShell title="Início" subtitle={`Bem-vindo de volta, ${mockPlayer.name}.`}>
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <section>
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-base tracking-wide text-bone">Suas campanhas</h2>
              <Link to="/campaigns" className="flex items-center gap-1 font-mono text-xs uppercase tracking-widest text-gold-bright hover:underline">
                Ver todas <ArrowRight size={13} />
              </Link>
            </div>

            <div className="space-y-3">
              {mockCampaigns.map((c) => (
                <Card key={c.id} interactive className="flex items-center justify-between gap-4 p-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="truncate font-display text-sm text-bone">{c.name}</h3>
                      <Badge tone={statusTone[c.status]}>{statusLabel[c.status]}</Badge>
                    </div>
                    <p className="mt-1 text-xs text-ash">
                      {c.theme} · {c.members}/{c.maxMembers} caçadores · {c.lastPlayedAt}
                    </p>
                  </div>
                  <Button variant="secondary" size="sm" className="shrink-0">
                    Entrar
                  </Button>
                </Card>
              ))}
            </div>
          </section>

          <section>
            <h2 className="mb-4 font-display text-base tracking-wide text-bone">Missões ativas</h2>
            <div className="space-y-3">
              {activeQuests.map((q) => (
                <Card key={q.id} className="p-4">
                  <h3 className="font-display text-sm text-bone">{q.title}</h3>
                  <p className="mt-1 text-xs text-ash">{q.description}</p>
                  <div className="mt-3 flex gap-1.5">
                    {q.objectives.map((o, i) => (
                      <div
                        key={i}
                        className={`h-1.5 flex-1 rounded-full ${o.done ? 'bg-gold' : 'bg-iron'}`}
                        title={o.label}
                      />
                    ))}
                  </div>
                </Card>
              ))}
            </div>
          </section>
        </div>

        <div className="space-y-6">
          <Card className="p-5">
            <h2 className="mb-4 font-display text-sm tracking-wide text-bone">Ações rápidas</h2>
            <div className="space-y-2.5">
              <Button variant="primary" className="w-full justify-between" icon={<Swords size={16} />}>
                Nova campanha
              </Button>
              <Link to="/character">
                <Button variant="secondary" className="w-full justify-between" icon={<ScrollText size={16} />}>
                  Ver ficha
                </Button>
              </Link>
              <Link to="/inventory">
                <Button variant="secondary" className="w-full justify-between" icon={<Backpack size={16} />}>
                  Ver inventário
                </Button>
              </Link>
            </div>
          </Card>

          <Card className="p-5">
            <h2 className="mb-1 font-display text-sm tracking-wide text-bone">Dossiê do caçador</h2>
            <p className="text-xs text-ash">Van Helsing · Nível 6 · Caçador de Monstros</p>
            <div className="mt-4 space-y-3">
              <div>
                <div className="mb-1 flex justify-between font-mono text-[11px] uppercase tracking-widest text-ash">
                  <span>Vida</span>
                  <span className="text-bone">62/80</span>
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-iron/50">
                  <div className="h-full rounded-full bg-blood" style={{ width: '77.5%' }} />
                </div>
              </div>
              <div>
                <div className="mb-1 flex justify-between font-mono text-[11px] uppercase tracking-widest text-ash">
                  <span>Sanidade</span>
                  <span className="text-bone">41/60</span>
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-iron/50">
                  <div className="h-full rounded-full bg-gold" style={{ width: '68%' }} />
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </AppShell>
  )
}
