// CampaignsPage.tsx
// "Lista de Campanhas": todas as salas do jogador, criar nova ou entrar
// com código de convite.

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Plus, KeyRound, Users } from 'lucide-react'
import AppShell from '@/components/layout/AppShell'
import Card from '@/components/ui/Card'
import Badge from '@/components/ui/Badge'
import Button from '@/components/ui/Button'
import Modal from '@/components/ui/Modal'
import TextField from '@/components/ui/TextField'
import { mockCampaigns } from '@/lib/mockData'

const statusTone = { active: 'success', waiting: 'gold', paused: 'default' } as const
const statusLabel = { active: 'Em andamento', waiting: 'Aguardando', paused: 'Pausada' } as const

export default function CampaignsPage() {
  const [modal, setModal] = useState<'create' | 'join' | null>(null)
  const navigate = useNavigate()

  return (
    <AppShell title="Campanhas" subtitle="Suas mesas de jogo — crie uma nova ou entre com um código de convite.">
      <div className="mb-6 flex flex-col gap-3 sm:flex-row">
        <Button variant="primary" icon={<Plus size={16} />} onClick={() => setModal('create')}>
          Criar campanha
        </Button>
        <Button variant="secondary" icon={<KeyRound size={16} />} onClick={() => setModal('join')}>
          Entrar com código
        </Button>
      </div>

      {mockCampaigns.length === 0 ? (
        <Card className="p-10 text-center">
          <p className="font-display text-base text-bone">Nenhuma campanha ainda</p>
          <p className="mt-2 text-sm text-ash">Crie uma investigação nova ou entre em uma sala com um código de convite.</p>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {mockCampaigns.map((c) => (
            <Card key={c.id} interactive className="flex flex-col p-5" onClick={() => navigate(`/campaigns/${c.id}/lobby`)}>
              <div className="mb-3 flex items-start justify-between">
                <Badge tone={statusTone[c.status]}>{statusLabel[c.status]}</Badge>
                <span className="font-mono text-[10px] uppercase tracking-widest text-ash">{c.lastPlayedAt}</span>
              </div>
              <h3 className="font-display text-base text-bone">{c.name}</h3>
              <p className="mt-1 text-xs text-ash">{c.theme}</p>

              <div className="mt-4 flex items-center justify-between border-t border-iron pt-4">
                <span className="flex items-center gap-1.5 text-xs text-ash">
                  <Users size={13} />
                  {c.members}/{c.maxMembers}
                </span>
                <span
                  className="inline-flex items-center gap-1 rounded-full border border-gold/40 bg-abyss px-2.5 py-0.5 font-mono text-[10px] tracking-[0.2em] text-gold-bright"
                  title="Código de convite"
                >
                  {c.inviteCode}
                </span>
              </div>
            </Card>
          ))}
        </div>
      )}

      {modal === 'create' && (
        <Modal title="Nova campanha" onClose={() => setModal(null)}>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault()
              setModal(null)
            }}
          >
            <TextField id="name" label="Nome da campanha" required placeholder="A Sombra de Borgo Pass" />
            <TextField id="theme" label="Cenário / tema" placeholder="Transilvânia, 1893" />
            <Button type="submit" variant="primary" className="w-full">
              Criar sala
            </Button>
          </form>
        </Modal>
      )}

      {modal === 'join' && (
        <Modal title="Entrar com código" onClose={() => setModal(null)}>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault()
              setModal(null)
            }}
          >
            <TextField
              id="code"
              label="Código de convite"
              required
              placeholder="X7QK2M"
              className="font-mono uppercase tracking-[0.3em]"
              maxLength={6}
            />
            <Button type="submit" variant="primary" className="w-full">
              Entrar na sala
            </Button>
          </form>
        </Modal>
      )}
    </AppShell>
  )
}
