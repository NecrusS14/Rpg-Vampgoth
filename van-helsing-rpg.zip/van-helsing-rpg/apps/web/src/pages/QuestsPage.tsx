// QuestsPage.tsx
// "Missões": missões ativas e concluídas da campanha.

import { useState } from 'react'
import { Check, Circle } from 'lucide-react'
import AppShell from '@/components/layout/AppShell'
import Card from '@/components/ui/Card'
import Badge from '@/components/ui/Badge'
import { mockQuests } from '@/lib/mockData'

const TABS = ['active', 'completed'] as const
const tabLabel = { active: 'Ativas', completed: 'Concluídas' }

export default function QuestsPage() {
  const [tab, setTab] = useState<(typeof TABS)[number]>('active')
  const quests = mockQuests.filter((q) => q.status === tab)

  return (
    <AppShell title="Missões" subtitle="Objetivos da campanha atual">
      <div className="mb-5 flex gap-2 border-b border-iron">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`border-b-2 px-1 pb-3 font-mono text-xs uppercase tracking-widest transition-colors ${
              tab === t ? 'border-gold-bright text-gold-bright' : 'border-transparent text-ash hover:text-bone'
            }`}
          >
            {tabLabel[t]} ({mockQuests.filter((q) => q.status === t).length})
          </button>
        ))}
      </div>

      {quests.length === 0 ? (
        <Card className="p-10 text-center">
          <p className="font-display text-base text-bone">Nada por aqui</p>
          <p className="mt-2 text-sm text-ash">Missões concluídas aparecerão aqui conforme a história avança.</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {quests.map((q) => (
            <Card key={q.id} className="p-5">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 className="font-display text-base text-bone">{q.title}</h3>
                  <p className="mt-1 text-sm text-ash">{q.description}</p>
                </div>
                <Badge tone={q.status === 'completed' ? 'success' : 'gold'}>
                  {q.status === 'completed' ? 'Concluída' : 'Em curso'}
                </Badge>
              </div>

              <ul className="mt-4 space-y-2 border-t border-iron pt-4">
                {q.objectives.map((o, i) => (
                  <li key={i} className="flex items-center gap-2.5 text-sm">
                    {o.done ? (
                      <Check size={15} className="shrink-0 text-gold-bright" />
                    ) : (
                      <Circle size={15} className="shrink-0 text-ash" />
                    )}
                    <span className={o.done ? 'text-ash line-through' : 'text-bone'}>{o.label}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      )}
    </AppShell>
  )
}
