// SettingsPage.tsx
// "Configurações": conta, preferências de jogo e zona de risco.

import { useState } from 'react'
import AppShell from '@/components/layout/AppShell'
import Card from '@/components/ui/Card'
import Button from '@/components/ui/Button'
import TextField from '@/components/ui/TextField'
import Avatar from '@/components/ui/Avatar'
import { mockCharacter, mockPlayer } from '@/lib/mockData'

function Toggle({ label, description, defaultChecked = false }: { label: string; description: string; defaultChecked?: boolean }) {
  const [checked, setChecked] = useState(defaultChecked)
  return (
    <div className="flex items-center justify-between py-3">
      <div className="pr-4">
        <p className="text-sm text-bone">{label}</p>
        <p className="text-xs text-ash">{description}</p>
      </div>
      <button
        onClick={() => setChecked((v) => !v)}
        className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${checked ? 'bg-blood' : 'bg-iron'}`}
        aria-pressed={checked}
      >
        <span
          className={`absolute top-0.5 h-5 w-5 rounded-full bg-bone transition-transform ${
            checked ? 'translate-x-5' : 'translate-x-0.5'
          }`}
        />
      </button>
    </div>
  )
}

export default function SettingsPage() {
  return (
    <AppShell title="Configurações" subtitle="Conta, preferências e privacidade">
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card className="p-6">
            <h2 className="mb-4 font-display text-sm tracking-wide text-bone">Perfil</h2>
            <div className="mb-5 flex items-center gap-4">
              <Avatar name={mockPlayer.name} size="lg" />
              <Button variant="secondary" size="sm">
                Alterar avatar
              </Button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <TextField id="username" label="Nome de exibição" defaultValue={mockPlayer.name} />
              <TextField id="email" label="E-mail" type="email" defaultValue="cacador@exemplo.com" />
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="mb-1 font-display text-sm tracking-wide text-bone">Preferências de jogo</h2>
            <div className="divide-y divide-iron">
              <Toggle label="Narração em áudio" description="Ouça a IA Mestre narrar em voz alta." defaultChecked />
              <Toggle label="Efeitos sonoros de dados" description="Toca um som a cada rolagem." defaultChecked />
              <Toggle label="Reduzir animações" description="Diminui transições e efeitos de movimento." />
              <Toggle label="Notificações de turno" description="Avisa quando for sua vez de agir." defaultChecked />
            </div>
          </Card>

          <Card className="border-blood/40 p-6">
            <h2 className="mb-1 font-display text-sm tracking-wide text-blood-bright">Zona de risco</h2>
            <p className="mb-4 text-xs text-ash">Ações abaixo não podem ser desfeitas.</p>
            <div className="flex flex-col gap-2.5 sm:flex-row">
              <Button variant="danger" size="sm">
                Sair de todas as campanhas
              </Button>
              <Button variant="danger" size="sm">
                Excluir conta
              </Button>
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="p-5">
            <h2 className="mb-3 font-display text-sm tracking-wide text-bone">Personagem ativo</h2>
            <div className="flex items-center gap-3">
              <Avatar name={mockCharacter.name} />
              <div>
                <p className="text-sm text-bone">{mockCharacter.name}</p>
                <p className="text-xs text-ash">
                  {mockCharacter.class} · Nível {mockCharacter.level}
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-5">
            <h2 className="mb-3 font-display text-sm tracking-wide text-bone">Conexão</h2>
            <p className="text-xs text-ash">
              Login anônimo. Conecte uma conta Google ou e-mail para não perder seu progresso.
            </p>
            <Button variant="secondary" size="sm" className="mt-3 w-full">
              Vincular conta
            </Button>
          </Card>
        </div>
      </div>
    </AppShell>
  )
}
