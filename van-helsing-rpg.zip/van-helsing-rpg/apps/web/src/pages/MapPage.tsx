// MapPage.tsx
// "Mapa": mapa da região com marcadores de locais descobertos/não
// descobertos. Usa um fundo texturizado em SVG (sem imagem externa).

import { useState } from 'react'
import { MapPin, Skull, Landmark, Home as HomeIcon } from 'lucide-react'
import AppShell from '@/components/layout/AppShell'
import Card from '@/components/ui/Card'
import { mockMapLocations } from '@/lib/mockData'

const kindIcon = {
  settlement: HomeIcon,
  landmark: Landmark,
  danger: Skull,
}

const kindTone = {
  settlement: 'text-gold-bright border-gold/50',
  landmark: 'text-bone border-iron',
  danger: 'text-blood-bright border-blood/50',
}

export default function MapPage() {
  const [selected, setSelected] = useState(mockMapLocations[0])

  return (
    <AppShell title="Mapa" subtitle="Região de Borgo Pass">
      <div className="grid gap-6 lg:grid-cols-[1fr_300px]">
        <Card className="relative aspect-[4/3] overflow-hidden p-0 sm:aspect-[16/10]">
          <div
            className="absolute inset-0"
            style={{
              background:
                'radial-gradient(ellipse 70% 60% at 30% 20%, rgba(122,18,32,0.10), transparent), radial-gradient(ellipse 60% 50% at 80% 80%, rgba(173,139,70,0.08), transparent), #171310',
            }}
          />
          <svg className="absolute inset-0 h-full w-full opacity-20" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#ad8b46" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>

          {mockMapLocations.map((loc) => {
            const Icon = kindIcon[loc.kind]
            const isSelected = selected.id === loc.id
            return (
              <button
                key={loc.id}
                onClick={() => setSelected(loc)}
                style={{ left: `${loc.x}%`, top: `${loc.y}%` }}
                className="group absolute -translate-x-1/2 -translate-y-1/2"
              >
                <div
                  className={`flex h-9 w-9 items-center justify-center rounded-full border-2 bg-charcoal transition-transform group-hover:scale-110 ${
                    kindTone[loc.kind]
                  } ${isSelected ? 'scale-110 shadow-seal' : ''} ${!loc.discovered ? 'opacity-40 grayscale' : ''}`}
                >
                  <Icon size={16} strokeWidth={1.75} />
                </div>
                <span className="absolute left-1/2 top-full mt-1.5 -translate-x-1/2 whitespace-nowrap rounded-sm bg-abyss/90 px-2 py-0.5 font-mono text-[10px] text-bone opacity-0 transition-opacity group-hover:opacity-100">
                  {loc.discovered ? loc.name : '???'}
                </span>
              </button>
            )
          })}
        </Card>

        <Card className="p-5">
          <h2 className="mb-4 font-display text-sm tracking-wide text-bone">Locais</h2>
          <div className="space-y-2">
            {mockMapLocations.map((loc) => {
              const Icon = kindIcon[loc.kind]
              return (
                <button
                  key={loc.id}
                  onClick={() => setSelected(loc)}
                  className={`flex w-full items-center gap-3 rounded-sm border px-3 py-2.5 text-left transition-colors ${
                    selected.id === loc.id ? 'border-gold/50 bg-gold/5' : 'border-transparent hover:bg-iron/20'
                  }`}
                >
                  <Icon size={16} className={loc.discovered ? 'text-gold-bright' : 'text-ash'} />
                  <span className={`text-sm ${loc.discovered ? 'text-bone' : 'text-ash'}`}>
                    {loc.discovered ? loc.name : 'Local não descoberto'}
                  </span>
                </button>
              )
            })}
          </div>

          {selected.discovered && (
            <div className="mt-5 border-t border-iron pt-4">
              <p className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-widest text-gold-bright">
                <MapPin size={12} /> Selecionado
              </p>
              <p className="mt-1.5 font-display text-sm text-bone">{selected.name}</p>
            </div>
          )}
        </Card>
      </div>
    </AppShell>
  )
}
