// RoomPage.tsx
// "Sala": a mesa de jogo em tempo real — narração da IA Mestre, chat,
// rolagem de dados e status do grupo. TODO: substituir os dados mockados
// por useGameSocket() quando o Socket.IO estiver conectado.

import { useState } from 'react'
import { useParams } from 'react-router-dom'
import { Dice6, Send } from 'lucide-react'
import AppShell from '@/components/layout/AppShell'
import Card from '@/components/ui/Card'
import Button from '@/components/ui/Button'
import Avatar from '@/components/ui/Avatar'
import StatBar from '@/components/ui/StatBar'
import { mockCampaigns, mockMessages, mockParty } from '@/lib/mockData'

const senderStyles = {
  narration: 'border-l-2 border-gold/50 bg-gold/5 text-bone/90 italic',
  player: 'bg-iron/20 text-bone',
  dice: 'bg-abyss border border-iron font-mono text-xs text-ash',
}

export default function RoomPage() {
  const { id } = useParams()
  const campaign = mockCampaigns.find((c) => c.id === id) ?? mockCampaigns[0]
  const [draft, setDraft] = useState('')

  return (
    <AppShell title={campaign.name} subtitle="Sessão em andamento">
      <div className="grid gap-6 lg:grid-cols-[1fr_280px]">
        {/* Narração + chat */}
        <div className="flex flex-col">
          <Card className="mb-4 overflow-hidden">
            <div
              className="flex h-40 items-end bg-gradient-to-t from-charcoal via-charcoal/60 to-transparent p-5 sm:h-52"
              style={{
                backgroundImage:
                  'linear-gradient(to top, rgba(23,19,16,0.95), rgba(23,19,16,0.5)), radial-gradient(ellipse at 30% 20%, rgba(122,18,32,0.25), transparent)',
              }}
            >
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-gold-bright">Cena atual</p>
                <h2 className="mt-1 font-display text-lg text-bone sm:text-xl">A Névoa de Borgo Pass</h2>
              </div>
            </div>
          </Card>

          <Card className="flex-1 p-4">
            <div className="mb-4 max-h-[420px] space-y-3 overflow-y-auto pr-1">
              {mockMessages.map((m) => (
                <div key={m.id} className={`rounded-sm px-3.5 py-2.5 text-sm ${senderStyles[m.senderType]}`}>
                  {m.senderType !== 'narration' && (
                    <p className="mb-0.5 font-mono text-[10px] uppercase tracking-widest text-ash">{m.sender}</p>
                  )}
                  {m.content}
                </div>
              ))}
            </div>

            <form
              className="flex items-center gap-2 border-t border-iron pt-3"
              onSubmit={(e) => {
                e.preventDefault()
                setDraft('')
              }}
            >
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                placeholder="Descreva sua ação..."
                className="flex-1 rounded-sm border border-iron bg-abyss px-3.5 py-2.5 text-sm text-bone placeholder:text-ash/50 focus:border-gold-bright/70"
              />
              <Button type="button" variant="secondary" size="md" icon={<Dice6 size={16} />} aria-label="Rolar dados" />
              <Button type="submit" variant="primary" size="md" icon={<Send size={16} />} aria-label="Enviar" />
            </form>
          </Card>
        </div>

        {/* HUD do grupo */}
        <div className="space-y-4">
          <Card className="p-4">
            <h2 className="mb-3 font-display text-sm tracking-wide text-bone">O grupo</h2>
            <div className="space-y-4">
              {mockParty.map((p) => (
                <div key={p.id} className="flex items-center gap-3">
                  <Avatar name={p.name} size="sm" />
                  <div className="flex-1">
                    <p className="mb-1 flex items-center justify-between text-xs text-bone">
                      <span>{p.name}</span>
                      <span className="text-ash">{p.className}</span>
                    </p>
                    <StatBar label="" current={p.hp.current} max={p.hp.max} tone="blood" />
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-4">
            <h2 className="mb-2 font-display text-sm tracking-wide text-bone">Ordem de turno</h2>
            <ol className="space-y-1.5 text-sm">
              {mockParty.map((p, i) => (
                <li
                  key={p.id}
                  className={`flex items-center gap-2 rounded-sm px-2.5 py-1.5 ${
                    i === 0 ? 'bg-gold/10 text-gold-bright' : 'text-ash'
                  }`}
                >
                  <span className="font-mono text-xs">{i + 1}</span>
                  {p.name}
                </li>
              ))}
            </ol>
          </Card>
        </div>
      </div>
    </AppShell>
  )
}
