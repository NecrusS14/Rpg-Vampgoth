// LoginPage.tsx
// Tela cheia de login/cadastro — sem AppShell (usuário ainda não entrou).

import LoginForm from '@/features/auth/LoginForm'

export default function LoginPage() {
  return (
    <div className="bg-noise flex min-h-screen items-center justify-center bg-abyss px-4 py-10">
      <div
        className="pointer-events-none fixed inset-0 opacity-60"
        style={{
          background:
            'radial-gradient(ellipse 60% 40% at 50% 20%, rgba(122,18,32,0.15), transparent), radial-gradient(ellipse 50% 30% at 80% 90%, rgba(173,139,70,0.08), transparent)',
        }}
      />
      <div className="relative">
        <LoginForm />
      </div>
    </div>
  )
}
