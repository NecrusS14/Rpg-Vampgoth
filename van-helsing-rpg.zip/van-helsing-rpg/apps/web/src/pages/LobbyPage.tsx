// LobbyPage.tsx
// "Lobby": sala de espera antes da sessão começar — membros, status de
// prontidão, código de convite e configurações da mesa.

import { useParams, useNavigate } from 'react-router-dom'
import { Check, Clock, Copy, Play } from 'lucide-react'
import AppShell from '@/components/layout/AppShell'
import Card from '@/components/ui/Card'
import Badge from '@/components/ui/Badge'
import Button from '@/components/ui/Button'
import Avatar from '@/components/ui/Avatar'
import { mockCampaigns, mockLobbyPlayers } from '@/lib/mockData'

export default function LobbyPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const campaign = mockCampaigns.find((c) => c.id === id) ?? mockCampaigns[0]
  const allReady = mockLobbyPlayers.every((p) => p.ready)

  return (
    <AppShell title={campaign.name} subtitle={`${campaign.theme} · Lobby da mesa`}>
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card className="p-5">
            <h2 className="mb-4 font-display text-sm tracking-wide text-bone">
              Caçadores na mesa ({mockLobbyPlayers.length}/{campaign.maxMembers})
            </h2>
            <div className="space-y-2.5">
              {mockLobbyPlayers.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between rounded-sm border border-iron bg-abyss/60 px-4 py-3"
                >
                  <div className="flex items-center gap-3">
                    <Avatar name={p.name} size="sm" />
                    <div>
                      <p className="flex items-center gap-2 font-body text-sm text-bone">
                        {p.name}
                        {p.isHost && <Badge tone="gold">Anfitrião</Badge>}
                      </p>
                      <p className="text-xs text-ash">{p.className}</p>
                    </div>
                  </div>
                  {p.ready ? (
                    <span className="flex items-center gap-1.5 text-xs text-emerald-400">
                      <Check size={14} /> Pronto
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5 text-xs text-ash">
                      <Clock size={14} /> Aguardando
                    </span>
                  )}
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="p-5">
            <h2 className="mb-3 font-display text-sm tracking-wide text-bone">Convite</h2>
            <div className="flex items-center justify-between rounded-sm border border-gold/30 bg-abyss px-4 py-3">
              <span className="font-mono text-lg tracking-[0.3em] text-gold-bright">{campaign.inviteCode}</span>
              <button className="rounded-sm p-1.5 text-ash transition-colors hover:bg-iron/40 hover:text-bone">
                <Copy size={15} />
              </button>
            </div>
            <p className="mt-2 text-xs text-ash">Compartilhe este código para outros caçadores entrarem na sala.</p>
          </Card>

          <Card className="p-5">
            <h2 className="mb-3 font-display text-sm tracking-wide text-bone">A aventura</h2>
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-ash">Cenário</dt>
                <dd className="text-bone">{campaign.theme}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-ash">Mestre</dt>
                <dd className="text-bone">IA Narradora</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-ash">Última sessão</dt>
                <dd className="text-bone">{campaign.lastPlayedAt}</dd>
              </div>
            </dl>
          </Card>

          <Button
            variant="primary"
            className="w-full"
            icon={<Play size={16} />}
            disabled={!allReady}
            onClick={() => navigate(`/campaigns/${campaign.id}/room`)}
          >
            {allReady ? 'Iniciar sessão' : 'Aguardando o grupo'}
          </Button>
        </div>
      </div>
    </AppShell>
  )
}
