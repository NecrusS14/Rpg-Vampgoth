// InventoryPage.tsx
// "Inventário": itens do personagem, com filtro por tipo e status de
// equipado.

import { useState } from 'react'
import { Sword, Shield, FlaskConical, Gem, Wrench, Package } from 'lucide-react'
import AppShell from '@/components/layout/AppShell'
import Card from '@/components/ui/Card'
import Badge from '@/components/ui/Badge'
import Button from '@/components/ui/Button'
import { mockInventory } from '@/lib/mockData'

const typeIcon = {
  weapon: Sword,
  armor: Shield,
  potion: FlaskConical,
  relic: Gem,
  tool: Wrench,
  misc: Package,
}

const typeLabel = {
  weapon: 'Arma',
  armor: 'Armadura',
  potion: 'Poção',
  relic: 'Relíquia',
  tool: 'Ferramenta',
  misc: 'Diversos',
}

const rarityTone = {
  common: 'default',
  uncommon: 'success',
  rare: 'gold',
  epic: 'blood',
  legendary: 'gold',
} as const

const FILTERS = ['todos', 'weapon', 'armor', 'potion', 'relic', 'tool'] as const

export default function InventoryPage() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>('todos')

  const items = filter === 'todos' ? mockInventory : mockInventory.filter((i) => i.type === filter)

  return (
    <AppShell title="Inventário" subtitle={`${mockInventory.length} itens carregados`}>
      <div className="mb-5 flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-full border px-3.5 py-1.5 font-mono text-[11px] uppercase tracking-widest transition-colors ${
              filter === f
                ? 'border-gold-bright bg-gold/10 text-gold-bright'
                : 'border-iron text-ash hover:border-gold/40 hover:text-bone'
            }`}
          >
            {f === 'todos' ? 'Todos' : typeLabel[f]}
          </button>
        ))}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {items.map((item) => {
          const Icon = typeIcon[item.type]
          return (
            <Card key={item.id} className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex h-11 w-11 items-center justify-center rounded-sm border border-iron bg-abyss text-gold-bright">
                  <Icon size={20} strokeWidth={1.5} />
                </div>
                {item.equipped && <Badge tone="gold">Equipado</Badge>}
              </div>

              <h3 className="mt-3 font-display text-sm text-bone">{item.name}</h3>
              <div className="mt-1.5 flex items-center gap-2">
                <Badge tone={rarityTone[item.rarity]}>{item.rarity}</Badge>
                <span className="text-xs text-ash">{typeLabel[item.type]}</span>
              </div>

              <div className="mt-4 flex items-center justify-between border-t border-iron pt-3">
                <span className="text-xs text-ash">Qtd. {item.quantity}</span>
                <Button variant="ghost" size="sm">
                  {item.equipped ? 'Remover' : 'Equipar'}
                </Button>
              </div>
            </Card>
          )
        })}
      </div>
    </AppShell>
  )
}
