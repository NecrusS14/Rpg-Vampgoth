// CharacterSheetPage.tsx
// "Ficha": atributos, vida, sanidade e efeitos de status do personagem.

import AppShell from '@/components/layout/AppShell'
import Card from '@/components/ui/Card'
import Badge from '@/components/ui/Badge'
import Avatar from '@/components/ui/Avatar'
import SealRing from '@/components/ui/SealRing'
import { mockCharacter } from '@/lib/mockData'

export default function CharacterSheetPage() {
  const c = mockCharacter
  const hpPct = (c.hp.current / c.hp.max) * 100
  const sanityPct = (c.sanity.current / c.sanity.max) * 100

  return (
    <AppShell title="Ficha" subtitle="Seu personagem nesta campanha">
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="flex flex-col items-center p-6 text-center lg:col-span-1">
          <Avatar name={c.name} size="lg" />
          <h2 className="mt-4 font-display text-lg text-bone">{c.name}</h2>
          <p className="text-sm text-ash">
            {c.class} · Nível {c.level}
          </p>

          <div className="mt-6 flex gap-6">
            <SealRing value={hpPct} tone="blood">
              <span className="font-display text-base text-bone">{c.hp.current}</span>
              <span className="font-mono text-[9px] uppercase tracking-widest text-ash">Vida</span>
            </SealRing>
            <SealRing value={sanityPct} tone="gold">
              <span className="font-display text-base text-bone">{c.sanity.current}</span>
              <span className="font-mono text-[9px] uppercase tracking-widest text-ash">Sanid.</span>
            </SealRing>
          </div>

          {c.statusEffects.length > 0 && (
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              {c.statusEffects.map((s) => (
                <Badge key={s.label} tone={s.tone}>
                  {s.label}
                </Badge>
              ))}
            </div>
          )}
        </Card>

        <div className="space-y-6 lg:col-span-2">
          <Card className="p-6">
            <h2 className="mb-4 font-display text-sm tracking-wide text-bone">Atributos</h2>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              {c.attributes.map((a) => (
                <div key={a.key} className="rounded-sm border border-iron bg-abyss/60 p-4 text-center">
                  <p className="font-mono text-[10px] uppercase tracking-widest text-ash">{a.label}</p>
                  <p className="mt-1 font-display text-2xl text-gold-bright">{a.value}</p>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="mb-4 font-display text-sm tracking-wide text-bone">Recursos</h2>
            <div className="space-y-5">
              <div>
                <div className="mb-1.5 flex justify-between font-mono text-[11px] uppercase tracking-widest text-ash">
                  <span>Vida</span>
                  <span className="text-bone">
                    {c.hp.current} / {c.hp.max}
                  </span>
                </div>
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-iron/50">
                  <div className="h-full rounded-full bg-blood transition-all" style={{ width: `${hpPct}%` }} />
                </div>
              </div>
              <div>
                <div className="mb-1.5 flex justify-between font-mono text-[11px] uppercase tracking-widest text-ash">
                  <span>Sanidade</span>
                  <span className="text-bone">
                    {c.sanity.current} / {c.sanity.max}
                  </span>
                </div>
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-iron/50">
                  <div className="h-full rounded-full bg-gold transition-all" style={{ width: `${sanityPct}%` }} />
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </AppShell>
  )
}
