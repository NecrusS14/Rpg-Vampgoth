// App.tsx
// Árvore de rotas da aplicação.
// TODO: reintroduzir <AuthGuard /> ao redor das rotas autenticadas quando
// o backend de autenticação (useAuth) for reconectado a esta interface.

import { Navigate, Route, Routes } from 'react-router-dom'
import LoginPage from './pages/LoginPage'
import HomePage from './pages/HomePage'
import CampaignsPage from './pages/CampaignsPage'
import LobbyPage from './pages/LobbyPage'
import RoomPage from './pages/RoomPage'
import CharacterSheetPage from './pages/CharacterSheetPage'
import InventoryPage from './pages/InventoryPage'
import MapPage from './pages/MapPage'
import QuestsPage from './pages/QuestsPage'
import SettingsPage from './pages/SettingsPage'

function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />

      <Route path="/" element={<HomePage />} />
      <Route path="/campaigns" element={<CampaignsPage />} />
      <Route path="/campaigns/:id/lobby" element={<LobbyPage />} />
      <Route path="/campaigns/:id/room" element={<RoomPage />} />
      <Route path="/character" element={<CharacterSheetPage />} />
      <Route path="/inventory" element={<InventoryPage />} />
      <Route path="/map" element={<MapPage />} />
      <Route path="/quests" element={<QuestsPage />} />
      <Route path="/settings" element={<SettingsPage />} />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export default App
