// PlayerList.tsx
// Lista de jogadores conectados na sessão (presença).
// TODO: consumir eventos 'presence:update'.

export default function PlayerList() {
  return null
}
