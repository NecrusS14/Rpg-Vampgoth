// SceneBanner.tsx
// Banner com descrição/imagem da cena atual.
// TODO: consumir 'gm:scene:update'.

export default function SceneBanner() {
  return null
}
