// NarrationFeed.tsx
// Feed de narração da IA Mestre (streaming de texto).
// TODO: consumir sessionStore (chunks de 'gm:narration:chunk').

export default function NarrationFeed() {
  return null
}
