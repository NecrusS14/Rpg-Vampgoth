// useGameSocket.ts
// Hook central de conexão Socket.IO da sessão de jogo.
// TODO: conectar, entrar na room (session:join), registrar listeners
// (gm:narration:*, combat:*, dice:result, presence:update) e popular
// o sessionStore (Zustand).

export function useGameSocket() {
  throw new Error('useGameSocket: not implemented yet')
}
