// ChatBox.tsx
// Chat de mesa (fala em personagem / OOC).
// TODO: emitir 'player:chat' e renderizar histórico.

export default function ChatBox() {
  return null
}
