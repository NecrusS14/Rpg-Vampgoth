// DiceRoller.tsx
// Componente de rolagem de dados.
// TODO: emitir 'player:dice:roll' e exibir 'dice:result'.

export default function DiceRoller() {
  return null
}
