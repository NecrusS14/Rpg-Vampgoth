// GameTable.tsx
// Container principal da sessão de jogo em tempo real.
// TODO: compor NarrationFeed, ChatBox, PlayerList, DiceRoller, SceneBanner.
// TODO: inicializar useGameSocket() ao montar.

export default function GameTable() {
  return null
}
