// CampaignList.tsx
// Lista de campanhas do usuário (dashboard).
// TODO: consumir useCampaigns() e renderizar CampaignCard por item.

export default function CampaignList() {
  return null
}
