// useCampaigns.ts
// Hook de dados: listar/criar/editar campanhas via React Query + REST API.
// TODO: implementar queries e mutations (lib/api.ts).

export function useCampaigns() {
  throw new Error('useCampaigns: not implemented yet')
}
