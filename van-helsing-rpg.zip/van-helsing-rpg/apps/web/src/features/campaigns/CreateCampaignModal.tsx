// CreateCampaignModal.tsx
// Modal de criação de nova campanha (nome, tema, descrição).
// TODO: formulário + chamada REST de criação (POST /api/campaigns).

export default function CreateCampaignModal() {
  return null
}
