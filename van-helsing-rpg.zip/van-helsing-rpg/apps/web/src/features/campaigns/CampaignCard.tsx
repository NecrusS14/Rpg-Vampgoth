// CampaignCard.tsx
// Card de exibição resumida de uma campanha.
// TODO: props (campaign: Campaign), navegação para CampaignSetupPage.

export default function CampaignCard() {
  return null
}
