// InitiativeOrder.tsx
// Ordem de iniciativa dos participantes do combate.
// TODO: renderizar turn_order e destacar participante atual.

export default function InitiativeOrder() {
  return null
}
