// useCombat.ts
// Hook de estado/ações de combate.
// TODO: integrar com sessionStore e eventos Socket.IO de combate.

export function useCombat() {
  throw new Error('useCombat: not implemented yet')
}
