// CombatTracker.tsx
// Painel de acompanhamento de combate (participantes, HP, turno atual).
// TODO: consumir 'combat:state:update' via useCombat().

export default function CombatTracker() {
  return null
}
