// ActionMenu.tsx
// Menu de ações de combate (atacar, usar item, fugir, etc.).
// TODO: emitir 'combat:action:submit'.

export default function ActionMenu() {
  return null
}
