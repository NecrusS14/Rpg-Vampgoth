// CharacterSheet.tsx
// Ficha de personagem: atributos, HP, sanidade, status.
// TODO: renderizar dados de Character (packages/shared).

export default function CharacterSheet() {
  return null
}
