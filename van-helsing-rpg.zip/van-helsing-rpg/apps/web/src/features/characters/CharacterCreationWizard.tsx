// CharacterCreationWizard.tsx
// Fluxo passo-a-passo de criação de personagem (classe, atributos, história).
// TODO: implementar wizard multi-etapas.

export default function CharacterCreationWizard() {
  return null
}
