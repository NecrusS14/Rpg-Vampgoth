// useCharacter.ts
// Hook de dados da ficha de personagem ativa.
// TODO: buscar/atualizar personagem via REST API.

export function useCharacter() {
  throw new Error('useCharacter: not implemented yet')
}
