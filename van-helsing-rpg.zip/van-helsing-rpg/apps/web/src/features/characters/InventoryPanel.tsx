// InventoryPanel.tsx
// Painel de inventário do personagem (itens, equipamentos).
// TODO: listar character_inventory e permitir equipar/usar itens.

export default function InventoryPanel() {
  return null
}
