// useAuth.ts
// Hook de autenticação: estado do usuário logado, login, logout.
// TODO: integrar com Supabase Auth (src/lib/supabaseClient.ts).

export function useAuth() {
  throw new Error('useAuth: not implemented yet')
}
