// LoginForm.tsx
// Formulário de autenticação: e-mail/senha (login e cadastro), entrada
// anônima e Google. Interatividade local nesta camada de interface —
// TODO: religar aos métodos reais de src/lib/supabaseClient quando o
// backend de autenticação for reconectado (ver useAuth.ts).

import { useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { Chrome, Fingerprint } from 'lucide-react'
import Button from '@/components/ui/Button'
import TextField from '@/components/ui/TextField'

type Mode = 'login' | 'signup'

export default function LoginForm() {
  const [mode, setMode] = useState<Mode>('login')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const navigate = useNavigate()

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError(null)
    setIsLoading(true)

    // TODO: chamar signInWithEmail / signUpWithEmail reais.
    window.setTimeout(() => {
      setIsLoading(false)
      navigate('/')
    }, 600)
  }

  function handleAnonymous() {
    setIsLoading(true)
    // TODO: chamar signInAnonymously real.
    window.setTimeout(() => {
      setIsLoading(false)
      navigate('/')
    }, 400)
  }

  function handleGoogle() {
    setIsLoading(true)
    // TODO: chamar signInWithGoogle real (redirecionamento OAuth).
    window.setTimeout(() => {
      setIsLoading(false)
      navigate('/')
    }, 400)
  }

  return (
    <div className="w-full max-w-sm rounded-md border border-gold/25 bg-charcoal p-8 shadow-seal">
      <div className="mb-7 flex flex-col items-center text-center">
        <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full border border-gold/40">
          <span className="font-display text-2xl text-gold-bright">V</span>
        </div>
        <h1 className="font-display text-xl tracking-[0.15em] text-bone">VAN HELSING</h1>
        <p className="mt-1.5 font-mono text-[11px] uppercase tracking-widest text-ash">Registro de Caçadores</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {mode === 'signup' && (
          <TextField id="username" label="Nome de caçador" type="text" required placeholder="Van Helsing" />
        )}
        <TextField id="email" label="E-mail" type="email" required placeholder="voce@exemplo.com" />
        <TextField id="password" label="Senha" type="password" required minLength={6} placeholder="••••••••" />

        {error && <p className="font-body text-sm text-blood-bright">{error}</p>}

        <Button type="submit" variant="primary" className="w-full" isLoading={isLoading}>
          {mode === 'login' ? 'Entrar' : 'Criar conta'}
        </Button>
      </form>

      <div className="my-6 flex items-center gap-3">
        <div className="h-px flex-1 bg-iron" />
        <span className="font-mono text-[10px] uppercase tracking-widest text-ash">ou</span>
        <div className="h-px flex-1 bg-iron" />
      </div>

      <div className="space-y-2.5">
        <Button variant="secondary" className="w-full" icon={<Chrome size={16} />} onClick={handleGoogle} disabled={isLoading}>
          Continuar com Google
        </Button>
        <Button variant="ghost" className="w-full" icon={<Fingerprint size={16} />} onClick={handleAnonymous} disabled={isLoading}>
          Entrar sem cadastro
        </Button>
      </div>

      <p className="mt-7 text-center font-body text-sm text-ash">
        {mode === 'login' ? (
          <>
            Não tem conta?{' '}
            <button type="button" onClick={() => setMode('signup')} className="text-gold-bright hover:underline">
              Cadastre-se
            </button>
          </>
        ) : (
          <>
            Já tem conta?{' '}
            <button type="button" onClick={() => setMode('login')} className="text-gold-bright hover:underline">
              Entrar
            </button>
          </>
        )}
      </p>
    </div>
  )
}
