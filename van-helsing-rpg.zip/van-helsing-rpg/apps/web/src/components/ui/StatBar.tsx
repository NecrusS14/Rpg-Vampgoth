// StatBar.tsx
// Barra linear para atributos que variam (HP, Sanidade, XP). Usada na
// Ficha, no Lobby (preview de personagem) e no HUD da Sala.

interface StatBarProps {
  label: string
  current: number
  max: number
  tone?: 'blood' | 'gold' | 'ash'
}

const toneClasses = {
  blood: 'bg-blood',
  gold: 'bg-gold',
  ash: 'bg-ash',
}

export default function StatBar({ label, current, max, tone = 'blood' }: StatBarProps) {
  const pct = max > 0 ? Math.min(100, Math.max(0, (current / max) * 100)) : 0

  return (
    <div>
      <div className="mb-1 flex items-center justify-between font-mono text-[11px] uppercase tracking-widest text-ash">
        <span>{label}</span>
        <span className="text-bone">
          {current}/{max}
        </span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-iron/50">
        <div
          className={`h-full rounded-full ${toneClasses[tone]} transition-all duration-500`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  )
}
