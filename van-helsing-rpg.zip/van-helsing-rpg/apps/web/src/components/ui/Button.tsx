// Button.tsx
// Botão base do design system. Três variantes: primary (vermelho oxidado,
// ação principal), secondary (contorno dourado envelhecido) e ghost
// (texto discreto). Sempre com foco visível e estado de carregamento.

import type { ButtonHTMLAttributes, ReactNode } from 'react'

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger'
type Size = 'sm' | 'md'

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant
  size?: Size
  icon?: ReactNode
  isLoading?: boolean
}

const variantClasses: Record<Variant, string> = {
  primary: 'bg-blood text-bone hover:bg-blood-bright shadow-[0_0_0_1px_rgba(122,18,32,0.4)]',
  secondary: 'border border-gold/40 bg-transparent text-bone hover:border-gold-bright hover:bg-gold/10',
  ghost: 'text-ash hover:text-bone hover:bg-iron/40',
  danger: 'border border-blood/50 bg-transparent text-blood-bright hover:bg-blood/10',
}

const sizeClasses: Record<Size, string> = {
  sm: 'px-3 py-1.5 text-xs',
  md: 'px-4 py-2.5 text-sm',
}

export default function Button({
  variant = 'primary',
  size = 'md',
  icon,
  isLoading = false,
  disabled,
  className = '',
  children,
  ...props
}: ButtonProps) {
  return (
    <button
      disabled={disabled || isLoading}
      className={`inline-flex items-center justify-center gap-2 rounded-sm font-body font-semibold uppercase tracking-wider transition-colors duration-150 disabled:cursor-not-allowed disabled:opacity-40 ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
      {...props}
    >
      {isLoading ? (
        <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-t-transparent" />
      ) : (
        icon
      )}
      {children}
    </button>
  )
}
