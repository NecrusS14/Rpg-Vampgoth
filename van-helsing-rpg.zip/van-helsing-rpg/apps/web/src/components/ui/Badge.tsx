// Badge.tsx
// Rótulo curto para status (ex: "ativa", "aguardando", "rara").

import type { HTMLAttributes } from 'react'

type Tone = 'default' | 'blood' | 'gold' | 'success'

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  tone?: Tone
}

const toneClasses: Record<Tone, string> = {
  default: 'border-iron bg-iron/30 text-ash',
  blood: 'border-blood/50 bg-blood/15 text-blood-bright',
  gold: 'border-gold/50 bg-gold/10 text-gold-bright',
  success: 'border-emerald-800/50 bg-emerald-950/40 text-emerald-400',
}

export default function Badge({ tone = 'default', className = '', children, ...props }: BadgeProps) {
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-widest ${toneClasses[tone]} ${className}`}
      {...props}
    >
      {children}
    </span>
  )
}
