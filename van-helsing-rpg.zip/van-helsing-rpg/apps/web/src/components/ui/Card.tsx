// Card.tsx
// Painel base: superfície "carvão" com borda dourada sutil, evocando uma
// placa de metal gravada. Usado em todas as telas para agrupar conteúdo.

import type { HTMLAttributes } from 'react'

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  interactive?: boolean
}

export default function Card({ interactive = false, className = '', children, ...props }: CardProps) {
  return (
    <div
      className={`rounded-md border border-iron bg-charcoal shadow-card ${
        interactive ? 'cursor-pointer transition-all duration-150 hover:border-gold/50 hover:shadow-seal' : ''
      } ${className}`}
      {...props}
    >
      {children}
    </div>
  )
}
