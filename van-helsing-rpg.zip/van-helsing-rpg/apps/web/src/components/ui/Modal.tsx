// Modal.tsx
// Modal simples com fundo escurecido e painel centralizado. Fecha ao
// clicar fora ou pressionar Escape.

import { useEffect } from 'react'
import type { ReactNode } from 'react'

interface ModalProps {
  title: string
  onClose: () => void
  children: ReactNode
  size?: 'sm' | 'md'
}

export default function Modal({ title, onClose, children, size = 'sm' }: ModalProps) {
  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [onClose])

  return (
    <div
      className="animate-fade-in fixed inset-0 z-50 flex items-center justify-center bg-abyss/80 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className={`w-full rounded-md border border-gold/30 bg-charcoal p-6 shadow-seal ${
          size === 'md' ? 'max-w-lg' : 'max-w-sm'
        }`}
      >
        <div className="mb-5 flex items-center justify-between">
          <h2 className="font-display text-lg tracking-wide text-bone">{title}</h2>
          <button
            onClick={onClose}
            aria-label="Fechar"
            className="rounded-sm p-1 text-ash transition-colors hover:bg-iron/50 hover:text-bone"
          >
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}
