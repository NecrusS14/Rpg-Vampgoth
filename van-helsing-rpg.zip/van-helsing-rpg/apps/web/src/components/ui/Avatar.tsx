// Avatar.tsx
// Avatar circular com aro dourado fino — pequenas "molduras de retrato"
// usadas em listas de jogadores, chat e cabeçalhos de ficha.

interface AvatarProps {
  name: string
  imageUrl?: string
  size?: 'sm' | 'md' | 'lg'
  ring?: boolean
}

const sizeClasses = {
  sm: 'h-8 w-8 text-xs',
  md: 'h-11 w-11 text-sm',
  lg: 'h-20 w-20 text-xl',
}

function initials(name: string) {
  return name
    .split(' ')
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('')
}

export default function Avatar({ name, imageUrl, size = 'md', ring = true }: AvatarProps) {
  return (
    <div
      className={`relative flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-iron font-display text-gold-bright ${sizeClasses[size]} ${
        ring ? 'ring-1 ring-gold/40' : ''
      }`}
    >
      {imageUrl ? (
        <img src={imageUrl} alt={name} className="h-full w-full object-cover" />
      ) : (
        <span>{initials(name)}</span>
      )}
    </div>
  )
}
