// SealRing.tsx
// ELEMENTO DE ASSINATURA VISUAL do projeto: um anel gravado, como um selo
// de cera ou brasão martelado. Reaproveitado em vários contextos:
//   - anel de HP/Sanidade na Ficha
//   - selo do código de convite na Sala/Lobby
//   - indicador de turno ativo no combate
// Sempre um círculo com aro duplo (externo dourado, interno tracejado)
// e o conteúdo centralizado.

import type { ReactNode } from 'react'

interface SealRingProps {
  value?: number // 0-100, desenha o arco de progresso (opcional)
  tone?: 'gold' | 'blood'
  size?: number
  children: ReactNode
}

export default function SealRing({ value, tone = 'gold', size = 88, children }: SealRingProps) {
  const stroke = tone === 'gold' ? '#d9b869' : '#a3182a'
  const radius = size / 2 - 6
  const circumference = 2 * Math.PI * radius
  const offset = value !== undefined ? circumference - (value / 100) * circumference : 0

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#2b2419" strokeWidth={3} />
        {value !== undefined && (
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={stroke}
            strokeWidth={3}
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            className="transition-all duration-500"
          />
        )}
      </svg>
      <div className="absolute inset-[6px] rounded-full border border-dashed border-iron" />
      <div className="absolute inset-0 flex flex-col items-center justify-center">{children}</div>
    </div>
  )
}
