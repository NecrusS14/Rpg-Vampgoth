// TextField.tsx
// Campo de texto padrão do design system.

import type { InputHTMLAttributes } from 'react'

interface TextFieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string
  hint?: string
}

export default function TextField({ label, hint, id, className = '', ...props }: TextFieldProps) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block font-mono text-[11px] uppercase tracking-widest text-ash">
        {label}
      </label>
      <input
        id={id}
        className={`w-full rounded-sm border border-iron bg-abyss px-3.5 py-2.5 font-body text-sm text-bone placeholder:text-ash/50 focus:border-gold-bright/70 ${className}`}
        {...props}
      />
      {hint && <p className="mt-1.5 font-body text-xs text-ash">{hint}</p>}
    </div>
  )
}
