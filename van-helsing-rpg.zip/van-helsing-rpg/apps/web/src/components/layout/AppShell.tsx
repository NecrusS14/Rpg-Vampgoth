// AppShell.tsx
// Casco estrutural da aplicação autenticada: trilho de navegação lateral
// no desktop, barra inferior no mobile. Contém também a barra superior
// com o título da página atual e o menu do jogador.
//
// Responsivo: < md exibe bottom nav + menu "mais"; >= md exibe o rail lateral
// fixo com rótulos.

import { useState, type ReactNode } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import {
  Castle,
  Swords,
  Backpack,
  Map as MapIcon,
  ScrollText,
  Settings,
  MoreHorizontal,
  LogOut,
  ChevronDown,
} from 'lucide-react'
import Avatar from '@/components/ui/Avatar'

interface NavItem {
  to: string
  label: string
  icon: typeof Castle
}

const PRIMARY_NAV: NavItem[] = [
  { to: '/', label: 'Início', icon: Castle },
  { to: '/campaigns', label: 'Campanhas', icon: Swords },
  { to: '/character', label: 'Ficha', icon: ScrollText },
  { to: '/inventory', label: 'Inventário', icon: Backpack },
]

const SECONDARY_NAV: NavItem[] = [
  { to: '/map', label: 'Mapa', icon: MapIcon },
  { to: '/quests', label: 'Missões', icon: ScrollText },
  { to: '/settings', label: 'Configurações', icon: Settings },
]

const ALL_NAV = [...PRIMARY_NAV, ...SECONDARY_NAV]

interface AppShellProps {
  title: string
  subtitle?: string
  children: ReactNode
}

export default function AppShell({ title, subtitle, children }: AppShellProps) {
  const [moreOpen, setMoreOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const navigate = useNavigate()

  // TODO: substituir pelo perfil real (useUserStore) quando a autenticação
  // estiver conectada a esta interface.
  const mockPlayer = { name: 'Van Helsing', role: 'Caçador' }

  function handleSignOut() {
    // TODO: chamar signOut() real e limpar sessão.
    navigate('/login')
  }

  return (
    <div className="flex min-h-screen bg-abyss bg-noise">
      {/* Rail lateral — desktop */}
      <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r border-iron bg-charcoal/60 md:flex">
        <div className="flex items-center gap-2.5 border-b border-iron px-5 py-5">
          <div className="flex h-9 w-9 items-center justify-center rounded-full border border-gold/40 font-display text-gold-bright">
            V
          </div>
          <span className="font-display text-sm tracking-[0.2em] text-bone">VAN HELSING</span>
        </div>

        <nav className="flex-1 space-y-1 px-3 py-4">
          {ALL_NAV.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-sm px-3 py-2.5 font-body text-sm transition-colors ${
                  isActive
                    ? 'border-l-2 border-gold-bright bg-gold/10 text-bone'
                    : 'border-l-2 border-transparent text-ash hover:bg-iron/30 hover:text-bone'
                }`
              }
            >
              <item.icon size={17} strokeWidth={1.75} />
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="border-t border-iron p-3">
          <button
            onClick={handleSignOut}
            className="flex w-full items-center gap-3 rounded-sm px-3 py-2.5 font-body text-sm text-ash transition-colors hover:bg-blood/10 hover:text-blood-bright"
          >
            <LogOut size={17} strokeWidth={1.75} />
            Sair
          </button>
        </div>
      </aside>

      {/* Coluna principal */}
      <div className="flex min-h-screen flex-1 flex-col">
        {/* Topbar */}
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-iron bg-abyss/90 px-4 py-4 backdrop-blur md:px-8">
          <div>
            <h1 className="font-display text-lg tracking-wide text-bone md:text-xl">{title}</h1>
            {subtitle && <p className="mt-0.5 text-xs text-ash">{subtitle}</p>}
          </div>

          <div className="relative">
            <button
              onClick={() => setUserMenuOpen((v) => !v)}
              className="flex items-center gap-2 rounded-sm border border-transparent px-2 py-1.5 transition-colors hover:border-iron"
            >
              <Avatar name={mockPlayer.name} size="sm" />
              <span className="hidden font-body text-sm text-bone sm:inline">{mockPlayer.name}</span>
              <ChevronDown size={14} className="text-ash" />
            </button>

            {userMenuOpen && (
              <div className="animate-fade-in absolute right-0 top-full mt-2 w-48 rounded-md border border-iron bg-charcoal p-1.5 shadow-seal">
                <NavLink
                  to="/settings"
                  onClick={() => setUserMenuOpen(false)}
                  className="block rounded-sm px-3 py-2 font-body text-sm text-bone hover:bg-iron/40"
                >
                  Configurações
                </NavLink>
                <button
                  onClick={handleSignOut}
                  className="block w-full rounded-sm px-3 py-2 text-left font-body text-sm text-blood-bright hover:bg-blood/10"
                >
                  Sair
                </button>
              </div>
            )}
          </div>
        </header>

        {/* Conteúdo */}
        <main className="flex-1 px-4 py-6 pb-24 md:px-8 md:pb-10">
          <div className="animate-fade-in mx-auto max-w-6xl">{children}</div>
        </main>
      </div>

      {/* Bottom nav — mobile */}
      <nav className="fixed inset-x-0 bottom-0 z-30 flex items-center justify-around border-t border-iron bg-charcoal/95 backdrop-blur md:hidden">
        {PRIMARY_NAV.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              `flex flex-1 flex-col items-center gap-1 py-2.5 text-[10px] uppercase tracking-wide ${
                isActive ? 'text-gold-bright' : 'text-ash'
              }`
            }
          >
            <item.icon size={19} strokeWidth={1.75} />
            {item.label}
          </NavLink>
        ))}
        <button
          onClick={() => setMoreOpen((v) => !v)}
          className={`flex flex-1 flex-col items-center gap-1 py-2.5 text-[10px] uppercase tracking-wide ${
            moreOpen ? 'text-gold-bright' : 'text-ash'
          }`}
        >
          <MoreHorizontal size={19} strokeWidth={1.75} />
          Mais
        </button>

        {moreOpen && (
          <div className="animate-fade-in absolute bottom-full right-2 mb-2 w-44 rounded-md border border-iron bg-charcoal p-1.5 shadow-seal">
            {SECONDARY_NAV.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={() => setMoreOpen(false)}
                className="flex items-center gap-2.5 rounded-sm px-3 py-2 font-body text-sm text-bone hover:bg-iron/40"
              >
                <item.icon size={16} strokeWidth={1.75} />
                {item.label}
              </NavLink>
            ))}
          </div>
        )}
      </nav>
    </div>
  )
}
