// useSupabaseAuth.ts
// Hook genérico de sessão do Supabase Auth (usuário, token, onAuthStateChange).
// TODO: implementar usando lib/supabaseClient.ts.

export function useSupabaseAuth() {
  throw new Error('useSupabaseAuth: not implemented yet')
}
