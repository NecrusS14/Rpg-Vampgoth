// useSocket.ts
// Hook genérico: instância única do socket.io-client, ciclo de vida
// de conexão/reconexão, autenticação via JWT do Supabase.
// TODO: implementar usando lib/socketClient.ts.

export function useSocket() {
  throw new Error('useSocket: not implemented yet')
}
