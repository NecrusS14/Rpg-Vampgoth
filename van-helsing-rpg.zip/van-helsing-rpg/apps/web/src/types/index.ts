// types/index.ts
// Tipos locais do frontend.
// Preferir importar tipos compartilhados de '@van-helsing/shared' quando possível.

export {}
