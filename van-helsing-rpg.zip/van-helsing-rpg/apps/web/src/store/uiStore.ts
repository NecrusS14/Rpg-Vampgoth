// uiStore.ts
// Estado global de UI (modais abertos, tema, sidebar).
// TODO: implementar store Zustand.

export {}
