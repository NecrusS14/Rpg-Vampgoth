// userStore.ts
// Estado global do usuário autenticado (perfil, personagem ativo).
// TODO: implementar store Zustand.

export {}
