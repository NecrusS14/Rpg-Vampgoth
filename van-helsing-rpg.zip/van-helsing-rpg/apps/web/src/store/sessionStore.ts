// sessionStore.ts
// Estado global da sessão de jogo atual (narração, combate, presença).
// TODO: implementar store Zustand alimentado por useGameSocket.
//
// Exemplo de shape (a implementar):
// {
//   narrationLog: NarrationEntry[]
//   combat: CombatState | null
//   onlinePlayers: PresenceEntry[]
//   appendNarration: (chunk: string) => void
//   updateCombat: (state: CombatState) => void
// }

export {}
