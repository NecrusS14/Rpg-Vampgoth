// mockData.ts
// Dados de exemplo usados nesta camada de interface para dar vida às telas
// antes da integração real com a API (apps/server) e o Supabase.
// TODO: substituir por dados vindos de useCampaigns / useCharacter / etc.

export const mockPlayer = {
  id: 'user-1',
  name: 'Van Helsing',
  role: 'Caçador Veterano',
}

export const mockCharacter = {
  name: 'Abraham Van Helsing',
  class: 'Caçador de Monstros',
  level: 6,
  hp: { current: 62, max: 80 },
  sanity: { current: 41, max: 60 },
  attributes: [
    { key: 'FOR', label: 'Força', value: 14 },
    { key: 'DES', label: 'Destreza', value: 16 },
    { key: 'INT', label: 'Intelecto', value: 18 },
    { key: 'VON', label: 'Vontade', value: 15 },
  ],
  statusEffects: [
    { label: 'Sangramento leve', tone: 'blood' as const },
    { label: 'Abençoado', tone: 'gold' as const },
  ],
}

export const mockCampaigns = [
  {
    id: 'camp-1',
    name: 'A Sombra de Borgo Pass',
    theme: 'Transilvânia, 1893',
    status: 'active' as const,
    members: 4,
    maxMembers: 6,
    inviteCode: 'X7QK2M',
    lastPlayedAt: 'há 2 dias',
  },
  {
    id: 'camp-2',
    name: 'O Convento Silencioso',
    theme: 'Cárpatos, 1894',
    status: 'waiting' as const,
    members: 2,
    maxMembers: 5,
    inviteCode: 'B4RT9L',
    lastPlayedAt: 'nunca jogada',
  },
  {
    id: 'camp-3',
    name: 'Sangue em Whitechapel',
    theme: 'Londres, 1888',
    status: 'paused' as const,
    members: 5,
    maxMembers: 5,
    inviteCode: 'F1NC8H',
    lastPlayedAt: 'há 3 semanas',
  },
]

export const mockLobbyPlayers = [
  { id: 'p1', name: 'Van Helsing', ready: true, isHost: true, className: 'Caçador' },
  { id: 'p2', name: 'Mina Harker', ready: true, isHost: false, className: 'Ocultista' },
  { id: 'p3', name: 'Jonathan Reed', ready: false, isHost: false, className: 'Padre-Guerreiro' },
  { id: 'p4', name: 'Sarah Blackwood', ready: false, isHost: false, className: 'Atiradora' },
]

export const mockParty = [
  { id: 'p1', name: 'Van Helsing', hp: { current: 62, max: 80 }, className: 'Caçador' },
  { id: 'p2', name: 'Mina Harker', hp: { current: 45, max: 50 }, className: 'Ocultista' },
  { id: 'p3', name: 'Jonathan Reed', hp: { current: 30, max: 70 }, className: 'Padre-Guerreiro' },
]

export const mockMessages = [
  { id: 'm1', senderType: 'narration' as const, sender: 'Mestre', content: 'A névoa se ergue sobre Borgo Pass. Um uivo distante corta o silêncio da floresta.' },
  { id: 'm2', senderType: 'player' as const, sender: 'Van Helsing', content: 'Acendo a lanterna e avanço com cautela em direção ao som.' },
  { id: 'm3', senderType: 'dice' as const, sender: 'Van Helsing', content: 'Percepção: 2d6+3 → 14' },
  { id: 'm4', senderType: 'narration' as const, sender: 'Mestre', content: 'Entre as árvores retorcidas, olhos vermelhos observam do escuro. Três, talvez quatro pares.' },
  { id: 'm5', senderType: 'player' as const, sender: 'Mina Harker', content: 'Preparo um selo de proteção, caso sejam lobisomens.' },
]

export const mockInventory = [
  { id: 'i1', name: 'Espada Abençoada', type: 'weapon' as const, rarity: 'epic' as const, quantity: 1, equipped: true },
  { id: 'i2', name: 'Crucifixo de Prata', type: 'relic' as const, rarity: 'rare' as const, quantity: 1, equipped: true },
  { id: 'i3', name: 'Poção de Cura Menor', type: 'potion' as const, rarity: 'common' as const, quantity: 3, equipped: false },
  { id: 'i4', name: 'Água Benta', type: 'potion' as const, rarity: 'uncommon' as const, quantity: 5, equipped: false },
  { id: 'i5', name: 'Armadura de Couro Cravejado', type: 'armor' as const, rarity: 'uncommon' as const, quantity: 1, equipped: true },
  { id: 'i6', name: 'Pólvora Consagrada', type: 'tool' as const, rarity: 'rare' as const, quantity: 2, equipped: false },
]

export const mockQuests = [
  {
    id: 'q1',
    title: 'O Sinal da Igreja Abandonada',
    description: 'Investigue os sinos que tocam sozinhos toda meia-noite na igreja de Borgo Pass.',
    status: 'active' as const,
    objectives: [
      { label: 'Chegar à igreja abandonada', done: true },
      { label: 'Encontrar a fonte do som', done: true },
      { label: 'Confrontar o que guarda o sino', done: false },
    ],
  },
  {
    id: 'q2',
    title: 'Rastros na Neve',
    description: 'Pegadas enormes foram avistadas nos arredores da vila. Descubra o que as deixou.',
    status: 'active' as const,
    objectives: [
      { label: 'Seguir os rastros', done: true },
      { label: 'Identificar a criatura', done: false },
    ],
  },
  {
    id: 'q3',
    title: 'A Carta do Professor',
    description: 'Entregar a carta de Van Helsing ao velho arquivista de Klausenburg.',
    status: 'completed' as const,
    objectives: [{ label: 'Entregar a carta', done: true }],
  },
]

export const mockMapLocations = [
  { id: 'loc1', name: 'Vila de Borgo Pass', x: 28, y: 62, discovered: true, kind: 'settlement' as const },
  { id: 'loc2', name: 'Igreja Abandonada', x: 45, y: 40, discovered: true, kind: 'landmark' as const },
  { id: 'loc3', name: 'Castelo na Montanha', x: 68, y: 22, discovered: false, kind: 'danger' as const },
  { id: 'loc4', name: 'Floresta Retorcida', x: 35, y: 30, discovered: true, kind: 'danger' as const },
  { id: 'loc5', name: 'Ponte de Pedra', x: 52, y: 55, discovered: true, kind: 'landmark' as const },
]
