// socketClient.ts
// Fábrica/instância do cliente Socket.IO, configurado com o JWT
// do Supabase no handshake de autenticação.
// TODO:
// import { io } from 'socket.io-client'
// export const createSocket = (token: string) =>
//   io(import.meta.env.VITE_SOCKET_URL, { auth: { token } })

export {}
