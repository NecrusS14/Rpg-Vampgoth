// supabaseClient.ts
// Cliente Supabase do frontend (anon key apenas).
// TODO:
// import { createClient } from '@supabase/supabase-js'
// export const supabase = createClient(
//   import.meta.env.VITE_SUPABASE_URL,
//   import.meta.env.VITE_SUPABASE_ANON_KEY,
// )

export {}
