// api.ts
// Wrapper fetch para a REST API do backend (apps/server).
// TODO: implementar funções tipadas por recurso (campaigns, characters, sessions).

export {}
