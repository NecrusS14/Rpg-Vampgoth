import type { Config } from 'tailwindcss'

// Sistema de design "Van Helsing" — dark fantasy moderno.
// Paleta: preto quente (abyss), carvão (charcoal/iron), cinza-osso (ash/bone),
// vermelho oxidado (blood) e dourado envelhecido (gold), com patina —
// nunca vermelho/dourado "brilhantes" de vitrine.
const config: Config = {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        abyss: '#0b0a08',
        charcoal: '#171310',
        iron: '#2b2419',
        ash: '#8a8072',
        bone: '#ece5d3',
        blood: {
          DEFAULT: '#7a1220',
          bright: '#a3182a',
          dim: '#4a0d16',
        },
        gold: {
          DEFAULT: '#ad8b46',
          bright: '#d9b869',
          dim: '#6e5a2e',
        },
      },
      fontFamily: {
        display: ['"Cinzel"', 'serif'],
        body: ['"Manrope"', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      boxShadow: {
        seal: '0 0 0 1px rgba(173, 139, 70, 0.35), 0 4px 24px -4px rgba(0,0,0,0.6)',
        card: '0 1px 0 0 rgba(236,229,211,0.04) inset, 0 8px 24px -12px rgba(0,0,0,0.7)',
      },
      backgroundImage: {
        grain:
          "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.05'/%3E%3C/svg%3E\")",
      },
      keyframes: {
        'fade-in': {
          '0%': { opacity: '0', transform: 'translateY(4px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        'fade-in': 'fade-in 0.25s ease-out',
      },
    },
  },
  plugins: [],
}

export default config
