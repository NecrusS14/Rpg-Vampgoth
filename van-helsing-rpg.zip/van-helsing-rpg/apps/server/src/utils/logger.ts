// logger.ts
// Logger centralizado (ex: pino ou console estruturado).
// TODO: implementar logger com níveis (info, warn, error) e formato JSON
// adequado para os logs do Railway.

export {}
