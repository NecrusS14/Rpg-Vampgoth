// errors.ts
// Classes de erro customizadas e handler central de erros do Express.
// TODO: implementar AppError, NotFoundError, ValidationError, etc.

export {}
