// combat.controller.ts
// Handlers relacionados a combate acionados via REST (se necessário).
// A maior parte da lógica de combate acontece via Socket.IO
// (ver sockets/handlers/combat.handlers.ts).
// TODO: definir endpoints auxiliares, se houver.

export {}
