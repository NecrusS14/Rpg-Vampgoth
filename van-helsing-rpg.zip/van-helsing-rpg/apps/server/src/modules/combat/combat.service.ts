// combat.service.ts
// Regras de negócio + acesso a dados para `combat_encounters` e
// `combat_participants`.
// TODO: iniciar encontro, calcular iniciativa, aplicar dano, encerrar combate.

export {}
