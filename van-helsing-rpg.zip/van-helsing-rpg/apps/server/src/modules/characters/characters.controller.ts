// characters.controller.ts
// Handlers HTTP para o recurso de personagens.
// TODO: validar entrada, chamar characters.service.ts, formatar resposta.

export {}
