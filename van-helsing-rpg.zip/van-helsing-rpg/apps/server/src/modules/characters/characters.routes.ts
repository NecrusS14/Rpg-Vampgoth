// characters.routes.ts
// GET    /api/characters?campaignId=
// POST   /api/characters
// GET    /api/characters/:id
// PATCH  /api/characters/:id
// TODO: implementar router Express ligado a characters.controller.ts.

export {}
