// characters.service.ts
// Regras de negócio + acesso a dados (Supabase) para personagens e inventário.
// TODO: CRUD de `characters` e `character_inventory`.

export {}
