// sessions.routes.ts
// POST   /api/sessions            (iniciar sessão de uma campanha)
// GET    /api/sessions/:id
// PATCH  /api/sessions/:id/end
// TODO: implementar router Express ligado a sessions.controller.ts.

export {}
