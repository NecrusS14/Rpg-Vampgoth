// sessions.controller.ts
// Handlers HTTP para o recurso de sessões de jogo.
// TODO: validar entrada, chamar sessions.service.ts, formatar resposta.

export {}
