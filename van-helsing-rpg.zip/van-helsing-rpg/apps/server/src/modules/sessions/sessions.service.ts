// sessions.service.ts
// Regras de negócio + acesso a dados (Supabase) para `sessions` e `game_events`.
// TODO: criar/encerrar sessão, gerar resumo ao final (sessions.summary).

export {}
