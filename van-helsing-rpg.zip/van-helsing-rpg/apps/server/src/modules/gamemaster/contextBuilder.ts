// contextBuilder.ts
// Monta o contexto enviado ao LLM: histórico recente de `game_events`,
// estado atual da cena, fichas resumidas dos personagens presentes.
// TODO: implementar busca e resumo de contexto (ver seção 7.3 do plano
// de arquitetura sobre gestão de contexto/custo).

export {}
