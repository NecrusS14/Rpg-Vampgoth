// tools.ts
// Definição das "tools" (function calling) que a IA Mestre pode sugerir,
// sempre validadas e aplicadas pelo backend antes de qualquer efeito real:
// - spawn_monster(monster_id, count)
// - apply_status_effect(character_id, effect)
// - trigger_combat(participants)
// - award_item(character_id, item_id)
// TODO: definir schemas das tools e handlers de validação/execução.

export {}
