// gamemaster.service.ts
// Orquestrador central da IA Mestre:
// 1. Recebe ação já processada pelo Rules Engine (services/rules-engine).
// 2. Usa contextBuilder para montar o prompt.
// 3. Chama o LLM (services/ai/anthropicClient.ts) em streaming.
// 4. Repassa chunks via Socket.IO (gm:narration:chunk).
// 5. Persiste o evento final em `game_events`.
// TODO: implementar orquestração completa.

export {}
