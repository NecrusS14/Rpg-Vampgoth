// auth.routes.ts
// Rotas relacionadas à autenticação (a maior parte é delegada ao Supabase Auth
// diretamente do frontend; aqui ficam endpoints auxiliares, se necessário,
// ex: sincronizar perfil na tabela `users` após signup).
// TODO: implementar router Express.

export {}
