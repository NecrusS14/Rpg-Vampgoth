// campaigns.routes.ts
// GET    /api/campaigns
// POST   /api/campaigns
// GET    /api/campaigns/:id
// PATCH  /api/campaigns/:id
// TODO: implementar router Express ligado a campaigns.controller.ts.

export {}
