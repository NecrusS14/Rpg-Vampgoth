// campaigns.service.ts
// Regras de negócio + acesso a dados (Supabase) para campanhas.
// TODO: CRUD de `campaigns` (definição da aventura) — ver também modules/rooms para `rooms` e `room_members`.

export {}
