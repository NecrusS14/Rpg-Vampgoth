// campaigns.controller.ts
// Handlers HTTP para o recurso de campanhas.
// TODO: validar entrada, chamar campaigns.service.ts, formatar resposta.

export {}
