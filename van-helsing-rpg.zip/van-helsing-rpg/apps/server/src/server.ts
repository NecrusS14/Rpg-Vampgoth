// server.ts
// Ponto de entrada do processo: cria o servidor HTTP e anexa
// Express (REST) + Socket.IO (tempo real).
// TODO:
// - import app from './app'
// - import { createServer } from 'node:http'
// - import { initSocket } from './sockets'
// - const httpServer = createServer(app)
// - initSocket(httpServer)
// - httpServer.listen(process.env.PORT || 4000)

export {}
