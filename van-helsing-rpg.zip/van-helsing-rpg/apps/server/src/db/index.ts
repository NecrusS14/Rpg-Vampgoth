// db/index.ts
// Ponto central de acesso a dados: reexporta helpers de queries agrupados
// por domínio (db/queries/*).
// TODO: implementar helpers tipados sobre o supabaseAdmin.

export {}
