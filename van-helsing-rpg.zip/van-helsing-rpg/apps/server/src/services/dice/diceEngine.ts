// diceEngine.ts
// Motor de rolagem de dados (ex: parsing de expressões como "2d6+3").
// TODO: implementar parser e gerador de rolagens determinístico/testável.

export {}
