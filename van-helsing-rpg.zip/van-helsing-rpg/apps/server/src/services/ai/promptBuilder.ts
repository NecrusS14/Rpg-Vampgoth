// promptBuilder.ts
// Monta o system prompt (persona do Mestre, tom gótico, regras de narrativa)
// e a mensagem de usuário (contexto dinâmico + resultado mecânico já
// calculado pelo rules-engine).
// TODO: implementar templates de prompt.

export {}
