// anthropicClient.ts
// Cliente da API da Anthropic usado pela IA Mestre.
// TODO:
// import Anthropic from '@anthropic-ai/sdk'
// export const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export {}
