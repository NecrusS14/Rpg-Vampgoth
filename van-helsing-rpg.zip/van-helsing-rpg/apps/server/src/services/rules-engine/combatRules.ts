// combatRules.ts
// Regras determinísticas de combate: cálculo de dano, acerto/erro,
// iniciativa. Roda ANTES da chamada à IA — a IA apenas narra o resultado.
// TODO: implementar fórmulas de combate do sistema de RPG.

export {}
