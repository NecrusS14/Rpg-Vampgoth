// progressionRules.ts
// Regras de progressão de personagem (XP, level up, atributos).
// TODO: implementar fórmulas de progressão.

export {}
