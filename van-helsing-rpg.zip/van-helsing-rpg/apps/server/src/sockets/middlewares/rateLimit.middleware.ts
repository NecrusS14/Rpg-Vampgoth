// rateLimit.middleware.ts
// Limita a frequência de eventos por socket (ex: evitar flood de ações/chat).
// TODO: implementar estratégia de rate limiting (ex: token bucket em memória
// ou Redis, se necessário no futuro).

export {}
