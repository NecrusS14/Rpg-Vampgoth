// socketAuth.middleware.ts
// Valida o JWT do Supabase enviado no handshake (`socket.handshake.auth.token`)
// e anexa `userId` ao socket. Recusa conexão sem token válido.
// TODO: implementar usando supabaseAdmin.auth.getUser(token).

export {}
