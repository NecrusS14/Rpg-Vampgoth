// sockets/index.ts
// Inicialização do Socket.IO Server.
// TODO:
// - criar instância Server(httpServer, { cors: ... })
// - aplicar middlewares (socketAuth, rateLimit)
// - registrar handlers por domínio (session, chat, combat, dice)
// - gerenciar rooms por session_id

export function initSocket() {
  throw new Error('initSocket: not implemented yet')
}
