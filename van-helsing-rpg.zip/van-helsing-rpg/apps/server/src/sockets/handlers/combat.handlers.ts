// combat.handlers.ts
// Eventos: combat:start, combat:turn:change, combat:action:submit,
// combat:state:update, combat:end.
// TODO: orquestrar fluxo de combate junto ao rules-engine e gamemaster.service.

export {}
