// dice.handlers.ts
// Eventos: player:dice:roll, dice:result.
// TODO: usar services/dice/diceEngine.ts e broadcast do resultado.

export {}
