// session.handlers.ts
// Eventos: session:join, session:leave, session:state:sync, presence:update.
// TODO: implementar entrada/saída de rooms e sincronização de estado inicial.

export {}
