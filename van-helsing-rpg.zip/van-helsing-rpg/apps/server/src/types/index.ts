// types/index.ts
// Tipos locais do backend (ex: Request estendido com userId autenticado).
// Preferir importar tipos compartilhados de '@van-helsing/shared' quando possível.

export {}
