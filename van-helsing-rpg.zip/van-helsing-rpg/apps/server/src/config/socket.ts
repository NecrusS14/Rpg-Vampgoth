// socket.ts
// Opções de configuração do Socket.IO Server (CORS, transports, adapters).
// TODO: exportar objeto de config consumido por sockets/index.ts.

export {}
