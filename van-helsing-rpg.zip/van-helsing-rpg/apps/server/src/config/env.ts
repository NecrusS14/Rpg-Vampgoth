// env.ts
// Carregamento e validação de variáveis de ambiente.
// TODO: usar dotenv/config + validação (ex: zod) para falhar rápido
// se SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY ou ANTHROPIC_API_KEY faltarem.

export {}
