// supabaseClient.ts
// Cliente Supabase do backend, usando a SERVICE ROLE KEY.
// Nunca expor esta chave ao frontend.
// TODO:
// import { createClient } from '@supabase/supabase-js'
// export const supabaseAdmin = createClient(
//   process.env.SUPABASE_URL!,
//   process.env.SUPABASE_SERVICE_ROLE_KEY!,
// )

export {}
