// routes/index.ts
// Agrega as rotas REST de cada módulo em um único router Express,
// montado em app.ts sob o prefixo /api.
// TODO:
// import { Router } from 'express'
// import authRoutes from '../modules/auth/auth.routes'
// import campaignsRoutes from '../modules/campaigns/campaigns.routes'
// import charactersRoutes from '../modules/characters/characters.routes'
// import sessionsRoutes from '../modules/sessions/sessions.routes'
// const router = Router()
// router.use('/auth', authRoutes)
// router.use('/campaigns', campaignsRoutes)
// router.use('/characters', charactersRoutes)
// router.use('/sessions', sessionsRoutes)
// export default router

export {}
