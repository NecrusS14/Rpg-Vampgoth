// app.ts
// Configuração da aplicação Express (middlewares, rotas REST).
// TODO:
// - app.use(cors({ origin: process.env.CORS_ORIGIN }))
// - app.use(express.json())
// - app.use('/api', routes) -> routes/index.ts
// - app.get('/health', ...) -> health check para o Railway

import express from 'express'

const app = express()

export default app
