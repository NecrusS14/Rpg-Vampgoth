# Van Helsing RPG — Mesa Online com IA Mestre

Monorepo do projeto: RPG de mesa online multiplayer, em tema gótico/vitoriano
inspirado em Van Helsing, com uma IA atuando como Mestre da Campanha.

> Este repositório contém apenas a **estrutura do projeto** (scaffolding).
> Nenhuma funcionalidade foi implementada ainda — ver `arquitetura-rpg-van-helsing.md`
> para o planejamento completo (arquitetura, banco de dados, eventos Socket.IO,
> fluxo da IA Mestre).

## Estrutura

```
apps/
  web/      -> Frontend (React + Vite + TypeScript + TailwindCSS) — deploy na Vercel
  server/   -> Backend (Node + Express + TypeScript + Socket.IO) — deploy no Railway
packages/
  shared/   -> Tipos e contratos (eventos Socket.IO, DTOs) compartilhados entre web e server
supabase/
  migrations/ -> Migrations SQL do banco de dados
```

## Requisitos

- Node.js >= 20
- npm >= 10
- Conta Supabase (Postgres + Auth)
- Chave de API da Anthropic (para a IA Mestre)

## Instalação

```bash
npm install
```

## Desenvolvimento

```bash
# Frontend (http://localhost:5173)
npm run dev:web

# Backend (http://localhost:4000)
npm run dev:server
```

## Variáveis de ambiente

Copie os arquivos `.env.example` de `apps/web` e `apps/server` para `.env`
e preencha com suas credenciais do Supabase e da Anthropic.

## Deploy

- **Frontend:** Vercel (root: `apps/web`)
- **Backend:** Railway (root: `apps/server`)
- **Banco de dados:** Supabase

## Status

🚧 Projeto em fase de estrutura/scaffolding. Nenhuma lógica de negócio implementada.
