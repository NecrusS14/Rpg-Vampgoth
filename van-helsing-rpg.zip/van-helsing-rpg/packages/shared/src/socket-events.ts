// socket-events.ts
// Nomes e (futuramente) payloads dos eventos Socket.IO, compartilhados
// entre client e server para evitar strings soltas e dessincronização.
//
// TODO: preencher com os eventos definidos no plano de arquitetura, ex:
// - session:join / session:leave / session:state:sync
// - presence:update
// - gm:narration:start / gm:narration:chunk / gm:narration:end
// - gm:scene:update
// - player:chat / player:action / player:dice:roll / dice:result
// - combat:start / combat:turn:change / combat:action:submit
//   / combat:state:update / combat:end
// - error / rate_limit:warning

export {}
