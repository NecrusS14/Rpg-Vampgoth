// rules.ts
// Constantes de regras de jogo compartilhadas (ex: tabelas de dano,
// níveis de dificuldade, limites de atributos).
// TODO: preencher conforme o sistema de regras do RPG for definido.

export {}
