// combat.ts
// TODO: definir CombatEncounter, CombatParticipant, Monster
// (espelhando as tabelas `combat_encounters`, `combat_participants`, `monsters`).

export {}
