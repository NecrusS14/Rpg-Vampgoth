// character.ts
// TODO: definir Character, Attributes, StatusEffect, InventoryItem, etc.
// (espelhando as tabelas `characters`, `character_inventory`, `items`).

export {}
