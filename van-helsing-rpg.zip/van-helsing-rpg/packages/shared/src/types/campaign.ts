// campaign.ts
// TODO: definir Campaign, CampaignMember, CampaignStatus, GmMode
// (espelhando a tabela `campaigns` — ver rooms.ts para `rooms` e `room_members`).

export {}
