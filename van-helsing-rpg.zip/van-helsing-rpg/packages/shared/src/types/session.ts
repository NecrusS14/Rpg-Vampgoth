// session.ts
// TODO: definir GameSession, GameEvent, EventType, ActorType
// (espelhando as tabelas `sessions`, `game_events`).

export {}
