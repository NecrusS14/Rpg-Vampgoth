// index.ts
// Ponto único de exportação do pacote @van-helsing/shared.
// Consumido tanto por apps/web quanto por apps/server.

export * from './types'
export * from './socket-events'
export * from './constants/rules'
